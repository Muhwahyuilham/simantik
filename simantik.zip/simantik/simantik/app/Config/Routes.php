<?php

namespace Config;

use App\Controllers\Satker\Home;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

// Load the system's routing file first, so that the app and ENVIRONMENT
// can override as needed.
if (file_exists(SYSTEMPATH . 'Config/Routes.php')) {
    require SYSTEMPATH . 'Config/Routes.php';
}

/*
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Home');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
$routes->setAutoRoute(true);

/*
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// We get a performance increase by specifying the default
// route since we don't have to scan directories.
$routes->get('/', 'Login::index');

// Admin Home
$routes->get('/admin', 'admin\Home::index', ['filter' => 'auth']);
// $routes->get('/admin/home', 'admin\Home::index', ['filter' => 'auth']);

// Admin Support
$routes->get('/admin/support', 'admin\Support::index', ['filter' => 'auth']);
$routes->get('/admin/support/lihat', 'admin\Support::lihat', ['filter' => 'auth']);
$routes->get('/admin/support/proses', 'admin\Support::proses', ['filter' => 'auth']);
$routes->get('/admin/support/detail/(:alphanum)', 'admin\Support::detail/$1', ['filter' => 'auth']);
$routes->get('/admin/support/simpanDetail', 'admin\Support::simpanDetail', ['filter' => 'auth']);

// Admin Jenis Support
$routes->get('/admin/jenissupport', 'admin\JenisSupport::index', ['filter' => 'auth']);
$routes->get('/admin/jenissupport/lihat', 'admin\JenisSupport::lihat', ['filter' => 'auth']);
$routes->get('/admin/jenissupport/simpan', 'admin\JenisSupport::simpan', ['filter' => 'auth']);
$routes->get('/admin/jenissupport/edit', 'admin\JenisSupport::edit', ['filter' => 'auth']);
$routes->get('/admin/jenissupport/delete', 'admin\JenisSupport::delete', ['filter' => 'auth']);

// Satker Home
$routes->get('/satker', 'satker\Home::index', ['filter' => 'auth']);
$routes->get('/satker/home', 'satker\Home::index', ['filter' => 'auth']);

// Satker Aplikasi
$routes->get('/satker/aplikasi', 'satker\Aplikasi::index', ['filter' => 'auth']);
$routes->get('/satker/aplikasi/tambah', 'satker\Aplikasi::tambah', ['filter' => 'auth']);
$routes->put('/satker/aplikasi/update', 'satker\Aplikasi::update', ['filter' => 'auth']);
$routes->post('/satker/aplikasi/simpan', 'satker\Aplikasi::simpan', ['filter' => 'auth']);

// Satker Infrastruktur
$routes->group('infrastruktur', ['namespace' => 'App\Controllers\Satker'], function($routes) {
    $routes->get('/', 'Infrastruktur::index');
    $routes->get('aktif', 'Infrastruktur::aktif');
    $routes->get('suspend', 'Infrastruktur::suspend');
    $routes->get('perbaikan', 'Infrastruktur::perbaikan');
    $routes->get('tidakaktif', 'Infrastruktur::tidakaktif');
    $routes->get('dimusnahkan', 'Infrastruktur::dimusnahkan');
    $routes->get('tambah', 'Infrastruktur::tambah');
    $routes->post('store', 'Infrastruktur::store');
    $routes->get('detail/(:segment)', 'Infrastruktur::detail/$1');
    $routes->get('edit/(:segment)', 'Infrastruktur::edit/$1');
    $routes->post('update', 'Infrastruktur::update');
});

// Satker Profile
$routes->get('/satker/profile', 'satker\Profile::index', ['filter' => 'auth']);

// Satker Support
$routes->get('/satker/support', 'satker\Support::lihat', ['filter' => 'auth']);
$routes->get('/satker/support/lihat', 'satker\Support::lihat', ['filter' => 'auth']);
$routes->get('/satker/support/permohonan', 'satker\Support::permohonan', ['filter' => 'auth']);
$routes->get('/satker/support/simpan', 'satker\Support::simpan', ['filter' => 'auth']);
$routes->get('/satker/support/detail/(:alphanum)', 'satker\Support::detail/$1', ['filter' => 'auth']);
$routes->get('/satker/support/simpanDetail', 'satker\Support::simpanDetail', ['filter' => 'auth']);

/*
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need to override any defaults in this file. Environment based routes
 * is one such time. require() additional route files here to make that
 * happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */
if (file_exists(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
    require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}
