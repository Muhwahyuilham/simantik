<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>SIMANTIK - REGISTER</title>
        <link href="<?= base_url('sbadmin/css/styles.css')?>" rel="stylesheet" />
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
        <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
       

    </head>
    <body class="bg-primary">
        <div id="layoutAuthentication">
            <div id="layoutAuthentication_content">
                <main>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-5">
                                <div class="card shadow-lg border-0 rounded-lg mt-5">
                                    <div class="card-header">
                                    <center><img src="<?= base_url().'assets/img/kemenag.png'; ?>" alt="logo" height="120px" width="130px">
                                    <h4 class="card-title">Sistem Informasi Manajemen TIK Kementerian Agama</h4></center>
                                    </div>
                                    <div class="card-body">
                                   
                                        <?php if(isset($validation)) { ?>
                                            <div class="alert alert-danger" role="alert">
                                                <?php echo $validation->listErrors() ?>
                                            </div>
                                        <?php } ?>
                                        
                                        <?php if(!empty(session()->getFlashdata('message'))) : ?>

                                        <div class="alert alert-success">
                                            <?php echo session()->getFlashdata('message');?>
                                        </div>
                                            
                                        <?php endif ?>

                                        
                                        <form id="validate" action="<?= base_url('registrasi/store') ?>" method="POST">
                                            <div class="form-group mb-3">
                                                <label>Nama</label>

                                                <input class="form-control" name="nama" type="text" placeholder="Masukan Nama Lengkap" />
                                               
                                            </div>

                                            <div class="form-group mb-3">
                                                <label>Email</label>

                                                <input class="form-control" id="email" name="email" type="email" placeholder="Masukan Email Dinas Kemenag" />
                                               
                                            </div>
                                            
                                            <div class="form-group mb-3">
                                                <label>Password</label>
                                                <input class="form-control" id="password" name="password" type="password" placeholder="Masukan Password" />
                                               
                                            </div>

                                            <div class="form-group mb-3">
                                                <label>Konfirmasi Password</label>
                                                <input class="form-control" id="confirmpassword" name="confirmpassword" type="password" placeholder="Masukan Confirm Password" />
                                                <span id="check_password_match"></span>
                                            </div>


                                            
                                            <div class="form-group mb-3">
                                                <label>Nomor WA</label>
                                                <input class="form-control" name="no_wa" type="text" placeholder="Masukan Nomor WA Aktif" />
                                               
                                            </div>
                                            
                                           

                                            <div class="form-group mb-3">
                                            <label>Nama Satker</label>
                                                <select class="form-select"  aria-label="Default select example" name="nama_satker" id="nama_satker">
                                                <?php foreach($allsatker as $satker){ ?>
                                                <option value="<?php echo $satker['nama_satker']; ?>"><?php echo $satker['nama_satker']; ?>   </option>
                                                <?php } ?>
                                                </select>
                                            </div>
                                            <input name="role" type="hidden" value="1" />
                                            <div class="mt-4 mb-0">
                                                <div class="d-grid">
                                                    <button type="submit" id="submit" class="btn btn-primary btn-block">Registrasi</button>  
                                                </div>
                                            
                                            </div>
                                            <!-- <div class="mt-4 mb-0">
                                                <div class="d-grid"><a class="btn btn-primary btn-block" href="login.html">Create Account</a></div>
                                            </div> -->
                                        </form>
                                    </div>
                                    <div class="card-footer text-center py-3">
                                        <div class="small"><a href="<?= base_url('login') ?>">Sudah Punya Akun? Silahkan Login</a></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
           
        </div>
        <script src="<?= base_url('sbadmin/js/scripts.js') ?>"></script>
        

    <script>
        $(document).on('keyup', '#confirmpassword', function () {
            let password = $("#password").val();
            let confirm_password = $("#confirmpassword").val();
            if (password != confirm_password) {
                $("#check_password_match").html("Password Tidak Sesuai !").css("color", "red");
            } else {
                $("#check_password_match").html("Password Sesuai !").css("color", "green");
            }
        });
    </script>
    <script type="text/javascript">	
	$(document).ready(function() {
		$('#nama_satker').select2();
	});
</script>


    </body>
</html>
