<!DOCTYPE html>
<html lang="en">
    <!-- Header -->
   <?= $this->include('admin/partials/head') ?>

   <!-- end Header -->


    <body class="sb-nav-fixed">
       
        <!-- navbar -->
        <?= $this->include('admin/partials/navbar') ?>

        <!-- end navbar -->


        <div id="layoutSidenav">
            
            <!-- sidebar-->
            <?= $this->include('admin/partials/sidebar') ?>

            <!-- end sidebar -->


            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <!-- Detail -->
                        <div class="card sticky-top" id="permohonan-support">
                            <div class="card-header">
                                <div class="row align-items-center">
                                    <div class="col-md-9 lh-1">
                                        <div><P class="fw-bold fs-3"><?= $request[0]->kode_request?></P></div>
                                        <div><P class="fw-normal"><?= $request[0]->jenis_support?></P></div>
                                        <div><P class="fw-normal"><?= $request[0]->nama_app?></P></div>
                                        <div><P class="fw-normal"><?= "Diajukan oleh ".$request[0]->nama." pada ".$request[0]->created_at?></P></div>    
                                    </div>
                                    <div class="col-md-3">
                                        <P class="fw-normal">Status :</P>
                                        <div><?php if ($request[0]->status==0) {
                                                        echo "<span class='badge bg-warning'><h3>Diajukan</h3></span>";
                                                    } elseif ($request[0]->status==1){
                                                        echo "<span class='badge bg-primary'><h3>Diproses</h3></span>";
                                                    } else {
                                                        echo "<span class='badge bg-success'><h3>Selesai</h3></span>";
                                                    }?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div style="margin-top:15pt;margin-bottom:15pt;">
                            <h3 class="header smaller lighter green">Pesan/Keterangan</h3>
                        </div>
                        
                        <?php foreach ($detail as $d) :
                            if ($d->email==session()->get()['email']) { ?>
                                <div class="card text-end lh-1" style="margin-top:15pt;margin-bottom:15pt;">
                                <div class="card-body bg-success bg-opacity-50">
                        <?php } else { ?>
                                <div class="card text-start" style="margin-top:15pt;margin-bottom:15pt;">
                                <div class="card-body bg-secondary bg-opacity-25">
                        <?php } ?>
                                <div class="fw-bold"><?= $d->nama."  - ".$d->created_at;?></div>
                                <hr>
                                <div><p><?= $d->detail;?></p></div>
                                <?php if ($d->file_pendukung!='') :?>
                                <div><a href="<?= $d->file_pendukung;?>" target="_blank" class="text-decoration-none text-reset"><i class="fa fa-download"></i> - File Pendukung</a></div>
                                <?php endif ?>
                                </div>
                                </div>
                       <?php endforeach ?>

                        
                        <div class="card sticky-bottom">
                            <?php if(!empty(session()->getFlashdata('error'))) : ?>
                            <div class="alert alert-danger">
                                <?php echo session()->getFlashdata('error');?>
                            </div>
                            <?php endif ?>
                        <?php if ($request[0]->status==0) { ?>
                            <div class="card-body">
                                    <div class="row text-center fs-3">
                                        <form action="<?= base_url('admin/support/proses') ?>" method="POST">
                                            <?= csrf_field();?>
                                            <input type="hidden" name="kode_request" value="<?= $request[0]->kode_request?>" />
                                            <button type="submit" class="btn btn-primary fs-4"><i class="fa fa-gear"></i>  Proses</button>
                                        </form>
                                    
                                    </div>                                    
                                </div>

                        <?php } elseif($request[0]->status==1) {?>
                                <div class="card-body bg-secondary bg-opacity-25 lh-1">
                                    <form action="<?= base_url('admin/support/simpanDetail') ?>" method="POST" enctype="multipart/form-data">
                                        <?= csrf_field(); ?>
                                        <input type="hidden" name="kode_request" value="<?= $request[0]->kode_request?>" />
                                        
                                        <div class="row align-items-center">
                                        
                                            <div class="col-sm-11">
                                                <label  for="detail" class="form-label">Pesan</label>
                                                <textarea class="form-control" name="detail" required></textarea>

                                                <label  for="file_pendukung" class="form-label" style="margin-top:5pt;">File Pendukung (.pdf .jpg .jpeg .png) </label>
                                                <input type="file" class="form-control" name="file_pendukung" id="file_pendukung" />
                                            </div>

                                            <div class="col-sm-1 order-last text-center fs-5">
                                                <div class="form-check form-switch">
                                                    <label class="form-check-label" for="flexSwitchCheckDefault">Selesai ?</label>
                                                    <input class="form-check-input" type="checkbox" id="flexSwitchCheckDefault" name="selesai">
                                                </div>
                                                <br />
                                                <button type="submit" class="btn btn-primary"><i class="fa fa-paper-plane"></i>  Kirim</button>
                                            </div>
                                        </div>
                                    
                                    </form>
                                </div>
                            <?php } elseif ($request[0]->status==2) { ?>
                                <div class="card-body bg-danger bg-opacity-25">
                                    <div class="row text-center fs-3">
                                    <p>Pekerjaan Telah Dinyatakan Selesai</p>
                                    </div>                                    
                                </div>
                            <?php }?>
                        </div>
                        

                        
                        
                    </div>
                </main>
              <?= $this->include('admin/partials/footer'); ?>
            </div>
        </div>
        <?= $this->include('admin/partials/js'); ?>
        <script>
            $(window).on('resize', function() {
                if($(window).width() > 400) {
                    $('#permohonan-support').addClass('sticky-top');
                }
            })
        </script>
    </body>
</html>
