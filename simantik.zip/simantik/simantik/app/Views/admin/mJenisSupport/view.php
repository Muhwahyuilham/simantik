<!DOCTYPE html>
<html lang="en">
    <!-- Header -->
   <?= $this->include('admin/partials/head') ?>

   <!-- end Header -->


    <body class="sb-nav-fixed">
       
        <!-- navbar -->
        <?= $this->include('admin/partials/navbar') ?>

        <!-- end navbar -->


        <div id="layoutSidenav">
            
            <!-- sidebar-->
            <?= $this->include('admin/partials/sidebar') ?>

            <!-- end sidebar -->


            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <!-- <h2 class="mt-4">Tambah Aplikasi</h2> -->
                        <div style="margin-top:15pt;margin-bottom:15pt;text-align:right">
                        <a href="#" data-bs-toggle="modal" data-bs-target="#modaltambahsupport"><button class="btn btn-danger">Tambah Jenis Support</button></a>
                        </div>
                        <div class="card mb-4">
                            
                            <div class="card-header">
                                <i class="fas fa-table me-1"></i>
                                JENIS SUPPORT
                            </div>
                            <div class="card-body">
                            <?php if(!empty(session()->getFlashdata('message'))) : ?>
                                <div class="alert alert-success">
                                    <?php echo session()->getFlashdata('message');?>
                                </div>
                                <?php endif ?>
                                <table id="datatablesSimple">
                                    <thead>
                                        <tr>
                                            <th>Nomor</th>
                                            <th>Jenis Support</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $n=1;
                                            foreach ($jenisSupport as $js) : ?>
                                                <tr>
                                                    <td><?= $n++;?></td>
                                                    <td><?= $js->jenis_support;?></td>
                                                    <td>
                                                    <a href="#" class="btn btn-sm btn-warning btn-edit" data-bs-toggle="modal" data-bs-target="#modaleditsupport" data-id="<?= $js->id;?>" data-nama="<?= $js->jenis_support;?>"><i class="fas fa-edit"></i></a>
                                            &nbsp;<a href="<?= base_url('admin/jenissupport/delete/'.$js->id); ?>" class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></a>
                                                    </td> </tr>
                                               
                                            <?php endforeach ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        
                    </div>
                </main>

                <!-- Modal Tambah Jenis Support -->
                <div class="modal fade" id="modaltambahsupport" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Tambah Jenis Support</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="<?= base_url('admin/jenissupport/simpan') ?>" method="POST" enctype="multipart/form-data">
                        <?= csrf_field();?>
                        <div class="mb-3">
                            <label for="jenis_support" class="col-form-label">Nama Support</label>
                            <input type="text" class="form-control" id="jenis_support" name="jenis_support">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Simpan</button>
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        </form>
                    </div>
                    </div>
                </div>
                </div>
                <!-- End Modal Tambah Jenis Support -->

                <!-- Modal Edit Jenis Support -->
                <div class="modal fade" id="modaleditsupport" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Tambah Jenis Support</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="<?= base_url('admin/jenissupport/edit') ?>" method="POST" enctype="multipart/form-data">
                        <?= csrf_field(); ?>
                        <div class="mb-3">
                            <input type="hidden" class="form-control id-support" id="id_support" name="id_support">
                        </div>
                        <div class="mb-3">
                            <label for="jenis_support" class="col-form-label">Nama Support</label>
                            <input type="text" class="form-control nama-post" id="jenis_support" name="jenis_support">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Simpan</button>
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        </form>
                    </div>
                    </div>
                </div>
                </div>
                <!-- End Modal Edit Jenis Support -->

              <?= $this->include('admin/partials/footer'); ?>
            </div>
        </div>
        <?= $this->include('admin/partials/js'); ?>
        <script>
            $(document).ready(function() {
                $('.btn-edit').on('click', function() {

                // get data from button edit
                const id = $(this).data('id');
                const nama = $(this).data('nama');

                // Set data to Form Edit
                $('.id-support').val(id);
                $('.nama-post').val(nama);
                
                // Call Modal Edit
                $('#modaleditsupport').modal('show');

            });
            });
        </script>
    </body>
</html>
