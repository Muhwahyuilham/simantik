<!DOCTYPE html>
<html lang="en">
    <!-- Header -->
   <?= $this->include('admin/partials/head') ?>

   <!-- end Header -->


    <body class="sb-nav-fixed">
       
        <!-- navbar -->
        <?= $this->include('admin/partials/navbar') ?>

        <!-- end navbar -->


        <div id="layoutSidenav">
            
            <!-- sidebar-->
            <?= $this->include('admin/partials/sidebar') ?>

            <!-- end sidebar -->


            <div id="layoutSidenav_content">
            <main>
                    <div class="container-fluid px-4">
                        <!-- <h2 class="mt-4">Tambah Aplikasi</h2> -->
                        
                        
                        <div class="card">
                            <div class="card-header">
                            TAMBAH JENIS SUPPORT
                            </div>
                            <div class="card-body">
                                <?php if(!empty(session()->getFlashdata('message'))) : ?>

                                <div class="alert alert-success">
                                    <?php echo session()->getFlashdata('message');?>
                                </div>
                                    
                                <?php endif ?>

                                <form action="<?= base_url('satker/aplikasi/simpan') ?>" method="POST">
                                    <input name="kode_aset" type="hidden" value="1" />
                                    <div class="mb-3">
                                        <label  for="kode_satker">Jenis Support</label>
                                        
                                        <select class="form-control" name="kode_satker">
                                        <option value="0">Biro HDI</option>
                                        <option value="1">Biro Perencanaan</option>
                                        <option value="2">Biro Ortala</option>
                                        <option value="3">Biro Kepegawaian</option>
                                        <option value="4">Biro Umum</option>
                                        </select>
                                       
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label  for="kode_aset">Aset yang disupport</label>
                                        
                                        <select class="form-control" name="kode_aset">
                                        <option value="0">Biro HDI</option>
                                        <option value="1">Biro Perencanaan</option>
                                        <option value="2">Biro Ortala</option>
                                        <option value="3">Biro Kepegawaian</option>
                                        <option value="4">Biro Umum</option>
                                        </select>
                                       
                                    </div>    

                                    <div class="mb-3">
                                        <label  class="form-label">Nama Aplikasi</label>
                                        <input type="text" class="form-control" name="nama_app">
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Deskripsi Aplikasi</label>
                                        <textarea class="form-control" name="desc_app" rows="3"></textarea>
                                    </div>

                                    <div class="mb-3">
                                        <label for="inputNama" class="form-label">Basis Aplikasi</label>
                                        <input type="text" class="form-control" name="basis_app">
                                    </div>

                                    <div class="mb-3">
                                        <label for="inputNama" class="form-label">Domain Aplikasi</label>
                                        <input type="text" class="form-control" name="url_app">
                                    </div>
                                    <div class="mb-3">
                                        <label for="inputNama" class="form-label">Bahasa Pemograman Aplikasi</label>
                                        <input type="text" class="form-control" name="prog_lang">
                                    </div>
                                    <div class="mb-3">
                                        <label for="inputNama" class="form-label"> Versi Bahasa Pemograman</label>
                                        <input type="text" class="form-control" name="prog_lang_ver">
                                    </div>
                                    <div class="mb-3">
                                        <label for="inputNama" class="form-label">Jenis Database</label>
                                        <input type="text" class="form-control" name="db_app">
                                    </div>
                                    <div class="mb-3">
                                        <label for="inputNama" class="form-label">Versi Database</label>
                                        <input type="text" class="form-control" name="db_ver">
                                    </div>
                                    <div class="mb-3">
                                        <label for="inputNama" class="form-label">Framework Aplikasi</label>
                                        <input type="text" class="form-control" name="framework">
                                    </div>
                                    <div class="mb-3">
                                        <label for="inputNama" class="form-label">Versi Framework</label>
                                        <input type="text" class="form-control" name="framework_ver">
                                    </div>

                                    <div class="mb-3">
                                        <label for="inputNama" class="form-label">Model Pengembangan</label>
                                        <select class="form-control" name="dev_model">
                                        <option value="0">Inhouse</option>
                                        <option value="1">Pihak Ke-3</option>
                                        </select>
                                    </div>
                                    
                                    
                                    <div class="mb-3">
                                        <label for="inputNama" class="form-label">Tahun Pengembangan</label>
                                        <input type="date" class="form-control" name="dev_year">
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Ketersediaan Source Code</label>
                                        <select class="form-control" name="source_code">
                                        <option value="0">Ada</option>
                                        <option value="1">Tidak Ada</option>
                                        
                                        </select>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Hosting Aplikasi</label>
                                        <input type="text" class="form-control" name="hosting_app">
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Pointing IP</label>
                                        <input type="text" class="form-control" name="pointing_ip">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Status Aplikasi</label>
                                        <select class="form-control" name="status_app">
                                        <option value="0">Aktif</option>
                                        <option value="1">Suspend</option>
                                        <option value="2">Dalam Perbaikan</option>
                                        <option value="3">Tidak Aktif</option>
                                        <option value="4">Dimusnahkan</option>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Arsitektur Aplikasi</label>
                                        <select class="form-control" name="arch_model">
                                        <option value="0">Monolithic</option>
                                        <option value="1">MicroService</option>
                                       
                                        </select>
                                    </div>

                                    




                                    
                                   

                                    <button type="submit" class="btn btn-primary">Submit</button>
                                    
                                    </form>
                            </div>
                        </div>
                        
                    </div>
                </main>
              <?= $this->include('admin/partials/footer'); ?>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="<?= base_url('sbadmin/js/scripts.js') ?>"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="<?= base_url('sbadmin/assets/demo/chart-area-demo.js') ?>"></script>
        <script src="<?= base_url('sbadmin/assets/demo/chart-bar-demo.js')?>"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
        <script src="<?= base_url('sbadmin/js/datatables-simple-demo.js')?>"></script>
    </body>
</html>
