<!DOCTYPE html>
<html lang="en">
    <!-- Header -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.8.0/js/bootstrap-datepicker.min.js"></script>
   <?= $this->include('admin/partials/head') ?>
   

   <!-- end Header -->

    <!-- Modal -->
    <?= $this->include('admin/partials/modalpassword') ?>

    <!-- end Modal -->


    <body class="sb-nav-fixed">
       
        <!-- navbar -->
        <?= $this->include('admin/partials/navbar') ?>

        <!-- end navbar -->


        <div id="layoutSidenav">
            
            <!-- sidebar-->
            <?= $this->include('admin/partials/sidebar') ?>

            <!-- end sidebar -->


            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <!-- <h2 class="mt-4">Tambah Aplikasi</h2> -->
                        
                        
                        <div class="card">
                            <div class="card-header">
                            DETAIL ASET APLIKASI
                            </div>
                            <div class="card-body">
                               

                                <form action="<?= base_url('admin/aplikasi/store') ?>" method="POST">
                                    
                                   
                                    
                                <div class="mb-3">
                                        <label  class="form-label">Nama Aplikasi</label>
                                        <input type="text" class="form-control" value="<?php echo ($alldata['nama_app']);?>" name="nama_app" readonly>
                                    </div>

                                    <div class="mb-3">
                                        <label  class="form-label">Kode Aset</label>
                                        <input type="text" class="form-control" value="<?php echo ($alldata['kode_aset']);?>" name="kode_aset" readonly>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Arsitektur Probis</label>
                                        <input type="text" class="form-control" name="pointing_ip" value="<?php echo ($alldata['arsitektur_probis']);?>" readonly>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Arsitektur App</label>
                                        <input type="text" class="form-control" name="pointing_ip" value="<?php echo ($alldata['arsitektur_app']);?>" readonly>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label">Deskripsi Aplikasi</label>
                                        <textarea class="form-control" name="desc_app" rows="3" readonly><?php echo ($alldata['desc_app']);?></textarea>
                                    </div>

                                    <div class="mb-3">
                                        <label  class="form-label">Fungsi Aplikasi</label>
                                        <input type="text" class="form-control" value="<?php echo ($alldata['fungsi_app']);?>" name="fungsi_app" readonly>
                                    </div>

                                    <div class="mb-3">
                                        <label  class="form-label">Output Aplikasi</label>
                                        <input type="text" class="form-control" value="<?php echo ($alldata['output_app']);?>" name="output_app" readonly>
                                    </div>

                                    
                                    

                                    

                                    <div class="mb-3">
                                        <label for="inputNama" class="form-label">Basis Aplikasi</label>
                                        <input type="text" class="form-control" value="<?php echo ($alldata['basis_app']);?>" name="basis_app" readonly>
                                    </div>

                                   

                                    <div class="mb-3">
                                        <label for="inputNama" class="form-label">Domain Aplikasi</label>
                                        <input type="text" class="form-control" value="<?php echo ($alldata['url_app']);?>" name="url_app" readonly>
                                    </div>
                                    <div class="mb-3">
                                        <label for="inputNama" class="form-label">Bahasa Pemograman Aplikasi</label>
                                        <input type="text" class="form-control" name="prog_lang" value="<?php echo ($alldata['prog_lang']);?>" readonly>
                                    </div>
                                    <div class="mb-3">
                                        <label for="inputNama" class="form-label"> Versi Bahasa Pemograman</label>
                                        <input type="text" class="form-control" name="prog_lang_ver" value="<?php echo ($alldata['prog_lang_ver']);?>" readonly>
                                    </div>
                                    <div class="mb-3">
                                        <label for="inputNama" class="form-label">Jenis Database</label>
                                        <input type="text" class="form-control" name="db_app" value="<?php echo ($alldata['db_app']);?>" readonly>
                                    </div>
                                    <div class="mb-3">
                                        <label for="inputNama" class="form-label">Versi Database</label>
                                        <input type="text" class="form-control" name="db_ver" value="<?php echo ($alldata['db_ver']);?>">
                                    </div>

                                    <div class="mb-3">
                                        <label for="inputNama" class="form-label">Nama Database</label>
                                        <input type="text" class="form-control" name="db_name" value="<?php echo ($alldata['db_name']);?>">
                                    </div>


                                    <div class="mb-3">
                                        <label for="inputNama" class="form-label">Nama Database</label>
                                        <input type="text" class="form-control" name="db_name" value="<?php echo ($alldata['db_name']);?>">
                                    </div>


                                    <div class="mb-3">
                                        <label for="inputNama" class="form-label">Framework Aplikasi</label>
                                        <input type="text" class="form-control" name="framework" value="<?php echo ($alldata['framework']);?>" readonly>
                                    </div>
                                    <div class="mb-3">
                                        <label for="inputNama" class="form-label">Versi Framework</label>
                                        <input type="text" class="form-control" name="framework_ver" value="<?php echo ($alldata['framework_ver']);?>" readonly>
                                    </div>

                                    <div class="mb-3">
                                        <label for="inputNama" class="form-label">Model Pengembangan</label>
                                        <input type="text" class="form-control" name="dev_model" value="<?php if($alldata['dev_model']==0){echo ("Inhouse");} else{echo ("Pihak ke-3");}?>" readonly>
                                    </div>


                                    <div class="mb-3">
                                        <label for="inputNama" class="form-label">Unit Pengembang</label>
                                        <input type="text" class="form-control" name="dev_unit" value="<?php echo ($alldata['framework_ver']);?>" readonly>
                                    </div>

                                   
                                    
                                    
                                    <div class="mb-3">
                                        <label for="inputNama" class="form-label">Tahun Pengembangan</label>
                                        <input type="text" class="form-control" name="dev_year" value="<?php echo ($alldata['dev_year']);?>" readonly>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Arsitektur Aplikasi</label>
                                        <input type="text" class="form-control" name="arch_model" value="<?php if($alldata['arch_model']==0){echo("Monolithic");}else{echo("Microservice");};?>" readonly>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Ketersediaan Source Code</label>
                                        <input type="text" class="form-control" name="source_code" value="<?php if($alldata['source_code'] == 0){echo ("Tersedia");}
                                                                                                                else{echo("Tidak Tersedia");}
                                                                                                            ?>" readonly>
                                        
                                        </select>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Tipe Lisensi</label>
                                        <select class="form-control" name="license_type" readonly>
                                        <option value="Terbuka/Open Source" <?php if($alldata['license_type']=='Terbuka/Open Source') echo 'selected="selected"';?>>Terbuka/Open Source</option>
                                        <option value="Tertutup/Berbayar" <?php if($alldata['license_type']=='Tertutup/Berbayar') echo 'selected="selected"';?>>Tertutup/Berbayar</option>
                                        </select>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Security Testing</label>
                                        
                                        <select class="form-control" name="sec_test" readonly>
                                        <option value="0" <?php if($alldata['sec_test']=='0') echo 'selected="selected"';?>>Belum</option>
                                        <option value="1" <?php if($alldata['sec_test']=='1') echo 'selected="selected"';?>>Sudah</option>
                                        </select>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Hosting Aplikasi</label>
                                        <input type="text" class="form-control" name="hosting_app" value="<?php echo ($alldata['hosting_app']);?>" readonly>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Pointing IP</label>
                                        <input type="text" class="form-control" name="pointing_ip" value="<?php echo ($alldata['pointing_ip']);?>" readonly>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Status Aplikasi</label>
                                        <input type="text" class="form-control" name="status_app" value="<?php if($alldata['status_app']==0){echo ("Aktif");}
                                                                                                        elseif($alldata['status_app']==1){echo ("Suspend");}
                                                                                                        elseif($alldata['status_app']==2){echo ("Dalam<br>Perbaikan");}
                                                                                                        elseif($alldata['status_app']==3){echo ("Tidak Aktif");}
                                                                                                        else{ echo ("Dimusnahkan");} ?>" readonly>
                                      
                                    </div>

                                    




                                    
                                   

                                   
                                    </form>
                            </div>
                        </div>
                        
                    </div>
                </main>
              <?= $this->include('admin/partials/footer'); ?>
            </div>
        </div>
        
        
        <?= $this->include('admin/partials/js'); ?>
        <!-- <script>
            $(document).ready(function () {
                $('#year-picker').datepicker({
                
                format: 'yyyy',
                viewMode: 'years',
                minViewMode: 'years'
                });
            })

        </script> -->
    </body>
</html>
