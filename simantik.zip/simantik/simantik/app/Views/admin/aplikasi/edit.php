<!DOCTYPE html>
<html lang="en">
    <!-- Header -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.8.0/js/bootstrap-datepicker.min.js"></script>
   <?= $this->include('admin/partials/head') ?>
   

   <!-- end Header -->

    <!-- Modal -->
    <?= $this->include('admin/partials/modalpassword') ?>

    <!-- end Modal -->


    <body class="sb-nav-fixed">
       
        <!-- navbar -->
        <?= $this->include('admin/partials/navbar') ?>

        <!-- end navbar -->


        <div id="layoutSidenav">
            
            <!-- sidebar-->
            <?= $this->include('admin/partials/sidebar') ?>

            <!-- end sidebar -->


            <div id="layoutSidenav_content">
                <main>
                <div class="container-fluid px-4">
                        <!-- <h2 class="mt-4">Tambah Aplikasi</h2> -->
                        
                        <h1 class="mt-4">EDIT ASET APLIKASI</h1>
                        <br>
                        <?php if(!empty(session()->getFlashdata('message'))) : ?>

                        <div class="alert alert-success">
                            <?php echo session()->getFlashdata('message');?>
                        </div>
                        <?php endif ?>
                        <form action="<?= base_url('admin/aplikasi/update') ?>" method="POST">
                        <div class="card">
                            <div class="card-header">
                            DETAIL ASET APLIKASI
                            </div>
                            <div class="card-body">    
                                    <input name="kode_aset" type="hidden" value="<?php echo ($alldata['kode_aset']);?>" />                                
                                    
                                    <div class="mb-3">
                                        <label  class="form-label">Nama Aplikasi</label>
                                        <input type="text" class="form-control" value="<?php echo ($alldata['nama_app']);?>" name="nama_app" required>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Deskripsi Aplikasi</label>
                                        &nbsp&nbsp<div class="tooltip-sendiri"><i class="fa-sharp fa-circle-question"></i>
                                                <span class="tooltip-teks">Uraikan definisi dari aplikasi</span>
                                                </div>
                                        <textarea class="form-control" name="desc_app" rows="3" required><?php echo ($alldata['desc_app']);?></textarea>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Fungsi Aplikasi</label>
                                        &nbsp&nbsp<div class="tooltip-sendiri"><i class="fa-sharp fa-circle-question"></i>
                                                <span class="tooltip-teks">Penjabaran fungsi-fungsi utama dalam aplikasi</span>
                                                </div>
                                        <textarea class="form-control" name="fungsi_app" rows="3" required><?php echo ($alldata['fungsi_app']);?></textarea>
                                    </div>

                                    <div class="mb-3">
                                        <label for="output_app" class="form-label">Output Aplikasi</label>
                                        <select class="form-control" name="output_app" required>
                                        <option value="Dokumen Layanan" <?php if($alldata['output_app']=='Dokumen Layanan') echo 'selected="selected"';?>>Dokumen Layanan</option>
                                        <option value="Dokumen Laporan" <?php if($alldata['output_app']=='Dokumen Laporan') echo 'selected="selected"';?>>Dokumen Laporan</option>
                                        </select>
                                    </div>

                                    <div class="mb-3">
                                        <label for="inputNama" class="form-label">Basis Aplikasi</label>
                                        <select class="form-control" name="basis_app" required>
                                        <option value="Web" <?php if($alldata['basis_app']=='Web') echo 'selected="selected"';?>>Web</option>
                                        <option value="Mobile IoS" <?php if($alldata['basis_app']=='Mobile IoS') echo 'selected="selected"';?>>Mobile IoS</option>
                                        <option value="Mobile Android" <?php if($alldata['basis_app']=='Mobile Android') echo 'selected="selected"';?>>Mobile Android</option>
                                        <option value="Desktop" <?php if($alldata['basis_app']=='Desktop') echo 'selected="selected"';?>>Desktop</option>
                                        </select>
                                    </div>

                                    <div class="mb-3">
                                        <label for="inputNama" class="form-label">Domain Aplikasi</label>
                                        &nbsp&nbsp<div class="tooltip-sendiri"><i class="fa-sharp fa-circle-question"></i>
                                                <span class="tooltip-teks">
                                                    - Untuk aplikasi Web mencantumkan URL <br>
                                                    - Untuk aplikasi Mobile mencantumkan link download Playstore / Appstore nya <br>
                                                    - Untuk aplikasi Desktop mencantumkan IP aplikasinya
                                                </span>
                                                </div>
                                        <input type="text" class="form-control" value="<?php echo ($alldata['url_app']);?>" name="url_app" required>
                                    </div>

                                    <div class="mb-3">
                                        <div class="row">
                                        <div class="col-md-6">
                                            <label for="inputNama" class="form-label">Bahasa Pemograman Aplikasi</label> 
                                            &nbsp&nbsp<div class="tooltip-sendiri"><i class="fa-sharp fa-circle-question"></i>
                                                    <span class="tooltip-teks">Bahasa pemrograman yang dominan digunakan di aplikasi, seperti PHP, JavaScript, Java, C, C++, dan lainnya
                                                    </span>
                                                </div>
                                            <input type="text" class="form-control" value="<?php echo ($alldata['prog_lang']);?>" name="prog_lang" required>
                                        </div>

                                        <div class="col-md-6">
                                            <label for="inputNama" class="form-label"> Versi Bahasa Pemograman</label>
                                            &nbsp&nbsp<div class="tooltip-sendiri"><i class="fa-sharp fa-circle-question"></i>
                                                    <span class="tooltip-teks">Versi dari Bahasa Pemrograman. Misal PHP 8.2, maka hanya ditulis 8.2 saja
                                                    </span>
                                                </div>
                                            <input type="text" class="form-control" value="<?php echo ($alldata['prog_lang_ver']);?>" name="prog_lang_ver" required>
                                        </div>
                                    </div>
                                    </div>

                                    <div class="mb-3">
                                        <div class="row">
                                            <div class="col-md-6">
                                            <label for="inputNama" class="form-label">Jenis Database</label>
                                        &nbsp&nbsp<div class="tooltip-sendiri"><i class="fa-sharp fa-circle-question"></i>
                                                <span class="tooltip-teks">Jenis Database yang digunakan di aplikasi, seperti MySQL, Postgree, MariaDB, Oracle, Firebase, dan lainnya
                                                </span>
                                            </div>
                                        <input type="text" class="form-control" value="<?php echo ($alldata['db_app']);?>" name="db_app" required>
                                            </div>

                                            <div class="col-md-6">
                                            <label for="db_ver" class="form-label">Versi Database</label>
                                        &nbsp&nbsp<div class="tooltip-sendiri"><i class="fa-sharp fa-circle-question"></i>
                                                <span class="tooltip-teks">Versi dari Database. Misal MariaDB 10.4.32, maka hanya ditulis 10.4.32 saja
                                                </span>
                                            </div>
                                        <input type="text" class="form-control" value="<?php echo ($alldata['db_ver']);?>" name="db_ver" required>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="mb-3">
                                        <label for="db_name" class="form-label">Nama Database</label>
                                        &nbsp&nbsp<div class="tooltip-sendiri"><i class="fa-sharp fa-circle-question"></i>
                                                <span class="tooltip-teks">Nama database yang digunakan di aplikasi</span>
                                            </div>
                                        <input type="text" class="form-control" value="<?php echo ($alldata['db_name']);?>" name="db_name" required>
                                    </div>

                                    <div class="mb-3">
                                        <div class="row">
                                            <div class="col-md-6"><label for="inputNama" class="form-label">Framework Aplikasi</label>
                                        &nbsp&nbsp<div class="tooltip-sendiri"><i class="fa-sharp fa-circle-question"></i>
                                                <span class="tooltip-teks">Jenis Framework yang digunakan di aplikasi, seperti CodeIgniter, Laravel, Flutter, NodeJS, NextJS, dan lainnya
                                                </span>
                                            </div>
                                        <input type="text" class="form-control" value="<?php echo ($alldata['framework']);?>" name="framework" required>
                                    </div>
                                            <div class="col-md-6">
                                            <label for="inputNama" class="form-label">Versi Framework</label>
                                        &nbsp&nbsp<div class="tooltip-sendiri"><i class="fa-sharp fa-circle-question"></i>
                                                <span class="tooltip-teks">Versi dari Framework aplikasi. Misal CodeIgniter 4, maka hanya ditulis 4 saja
                                                </span>
                                            </div>
                                        <input type="text" class="form-control" value="<?php echo ($alldata['framework_ver']);?>" name="framework_ver" required>
                                            </div>
                                        </div>         
                                    </div>

                                    <div class="mb-3">
                                        <label for="inputNama" class="form-label">Model Pengembangan</label>
                                        &nbsp&nbsp<div class="tooltip-sendiri"><i class="fa-sharp fa-circle-question"></i>
                                                <span class="tooltip-teks">pengembangan aplikasi dilakukan secara Inhouse (dikerjakan oleh Sumber Daya Manusia sendiri) atau oleh Pihak Ke-3
                                                </span>
                                            </div>
                                        <select class="form-control" name="dev_model" required>
                                        <option value="0" <?php if($alldata['dev_model']=='0') echo 'selected="selected"';?>>Inhouse</option>
                                        <option value="1" <?php if($alldata['dev_model']=='1') echo 'selected="selected"';?>>Pihak Ke-3</option>
                                        </select>
                                    </div>

                                    <div class="mb-3">
                                        <label for="dev_unit" class="form-label">Unit Pengembang</label>
                                        &nbsp&nbsp<div class="tooltip-sendiri"><i class="fa-sharp fa-circle-question"></i>
                                                <span class="tooltip-teks">Unit Kerja/Pihak yang mengembangkan aplikasi</span>
                                            </div>
                                        <input type="text" class="form-control" value="<?php echo ($alldata['dev_unit']);?>" name="dev_unit" required>
                                    </div> 
                                    
                                    <div class="mb-3">
                                        <label for="inputNama" class="form-label">Tahun Pengembangan</label>
                                        <input type="number" class="form-control" value="<?php echo ($alldata['dev_year']);?>" name="dev_year" required>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Arsitektur Aplikasi</label>
                                        <select class="form-control" name="arch_model">
                                        <option value="0" <?php if($alldata['arch_model']=='0') echo 'selected="selected"';?>>Monolithic</option>
                                        <option value="1" <?php if($alldata['arch_model']=='1') echo 'selected="selected"';?>>MicroService</option>
                                        </select>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Ketersediaan Source Code</label>
                                        <select class="form-control" name="source_code" required>
                                        <option value="0" <?php if($alldata['source_code']=='0') echo 'selected="selected"';?>>Tidak Ada</option>
                                        <option value="1" <?php if($alldata['source_code']=='1') echo 'selected="selected"';?>>Ada</option>
                                        </select>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Tipe Lisensi</label>
                                        <select class="form-control" name="license_type" required>
                                        <option value="Terbuka/Open Source" <?php if($alldata['license_type']=='Terbuka/Open Source') echo 'selected="selected"';?>>Terbuka/Open Source</option>
                                        <option value="Tertutup/Berbayar" <?php if($alldata['license_type']=='Tertutup/Berbayar') echo 'selected="selected"';?>>Tertutup/Berbayar</option>
                                        </select>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Security Testing</label>
                                        &nbsp&nbsp<div class="tooltip-sendiri"><i class="fa-sharp fa-circle-question"></i>
                                                <span class="tooltip-teks">Aplikasi pernah dilakukan pengujian keamanan seperti pentest, stress test, IT Security Assesment, dsb
                                                </span>
                                            </div>
                                        <select class="form-control" name="sec_test" required>
                                        <option value="0" <?php if($alldata['sec_test']=='0') echo 'selected="selected"';?>>Belum</option>
                                        <option value="1" <?php if($alldata['sec_test']=='1') echo 'selected="selected"';?>>Sudah</option>
                                        </select>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Hosting Aplikasi</label>
                                        &nbsp&nbsp<div class="tooltip-sendiri"><i class="fa-sharp fa-circle-question"></i>
                                                <span class="tooltip-teks">Lokasi penempatan hosting aplikasi apakah di Server Biro HDI, di Server Satker (Sebutkan Satkernya), di Cloud (Sebutkan Cloudnya), atau di hosting di Pihak Ke-3
                                                </span>
                                            </div>
                                        <input type="text" class="form-control" value="<?php echo ($alldata['hosting_app']);?>" name="hosting_app" required>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Pointing IP</label>
                                        &nbsp&nbsp<div class="tooltip-sendiri"><i class="fa-sharp fa-circle-question"></i>
                                                <span class="tooltip-teks">IP yang dipointing untuk mendapatkan domain kemenag.go.id
                                                </span>
                                            </div>
                                        <input type="text" class="form-control" value="<?php echo ($alldata['pointing_ip']);?>" name="pointing_ip" required>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Status Aplikasi</label>
                                        <select class="form-control" name="status_app">
                                        <option value="0" <?php if($alldata['status_app']=='0') echo 'selected="selected"';?>>Aktif</option>
                                        <option value="1" <?php if($alldata['status_app']=='1') echo 'selected="selected"';?>>Suspend</option>
                                        <option value="2" <?php if($alldata['status_app']=='2') echo 'selected="selected"';?>>Dalam Perbaikan</option>
                                        <option value="3" <?php if($alldata['status_app']=='3') echo 'selected="selected"';?>>Tidak Aktif</option>
                                        <option value="4" <?php if($alldata['status_app']=='4') echo 'selected="selected"';?>>Dimusnahkan</option>
                                        </select>
                                    </div>
                                      
                            </div>
                        </div>
                        <br>
                        <div class="card">
                            <div class="card-header">
                                REFERENSI ARSITEKTUR APLIKASI
                            </div>
                            <div class="card-body">

                                    <div class="mb-3">
                                        <label class="form-label">Tingkat 1 - Domain Aplikasi</label>
                                        <select class="form-control" name="level1">
                                        <option value="02" <?php if($arsitektur_app['level1']=='02') echo 'selected="selected"';?>>Aplikasi Khusus</option>
                                        </select>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Tingkat 2 - Area Aplikasi</label>
                                        <select class="form-control" name="level2">
                                        <option value="01" <?php if($arsitektur_app['level2']=='01') echo 'selected="selected"';?>>Aplikasi Misi Tertentu</option>
                                        <option value="02" <?php if($arsitektur_app['level2']=='02') echo 'selected="selected"';?>>Aplikasi Fungsi Tertentu</option>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Tingkat 3 - Kategori Aplikasi</label>
                                        <select class="form-control" name="level3">
                                            <?php
                                            for ($i=0;$i< count($referensi) ;$i++){
                                                ?>
                                                <option value="<?= $referensi[$i]->kode_referensi;?>" <?php if($arsitektur_app['level3']=='0'.$i+1 ) echo 'selected="selected"';?>><?= $referensi[$i]->nama_referensi;?></option>                                                
                                                <?php
                                            }
                                            ?>
                                        
                                        </select>
                                    </div>
                            </div>
                        </div>
                        <br>
                        <div class="d-grid col-3 mx-auto">
                        <button type="submit" class="btn btn-primary"> <i class="fas fa-paper-plane"> </i> Submit</button>
                        </div>
                        </form>
                    </div>
                </main>
              <?= $this->include('admin/partials/footer'); ?>
            </div>
        </div>
        
        
        <?= $this->include('admin/partials/js'); ?>
        <!-- <script>
            $(document).ready(function () {
                $('#year-picker').datepicker({
                
                format: 'yyyy',
                viewMode: 'years',
                minViewMode: 'years'
                });
            })

        </script> -->
    </body>
</html>
