<!DOCTYPE html>
<html lang="en">
    <!-- Header -->
   <?= $this->include('satker/partials/head') ?>

   <!-- end Header -->

   


    <body class="sb-nav-fixed">
       
        <!-- navbar -->
        <?= $this->include('satker/partials/navbar') ?>

        <!-- end navbar -->


        <div id="layoutSidenav">
            
            <!-- sidebar-->
            <?= $this->include('satker/partials/sidebar') ?>

            <!-- end sidebar -->


            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        
                        
                        
                        <div class="card">
                            <div class="card-header">
                            Profile User
                            </div>
                            <div class="card-body">
                                <?php if(!empty(session()->getFlashdata('message'))) : ?>

                                <div class="alert alert-success">
                                    <?php echo session()->getFlashdata('message');?>
                                </div>
                                    
                                <?php endif ?>
                                <?php if(!empty(session()->getFlashdata('errormessage'))) : ?>

                                <div class="alert alert-danger">
                                    <?php echo session()->getFlashdata('errormessage');?>
                                </div>
                                    
                                <?php endif ?>

                                <form action="<?= base_url('satker/profile/update') ?>" method="POST">
                                    <input name="id" type="hidden" value="<?php echo ($alldata['id']);?>" />
                                    
                                    
                                    <div class="mb-3">
                                        <label  class="form-label">Nama</label>
                                        <input type="text" class="form-control" value="<?php echo ($alldata['nama']);?>" name="nama">
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Email</label>
                                        <input type="text" class="form-control" value="<?php echo ($alldata['email'])?>" name="email">
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">No WA</label>
                                        <input type="text" class="form-control" value="<?php echo ($alldata['no_wa']);?>" name="no_wa">
                                    </div>

                                    
                                   
                                    <button type="submit" class="btn btn-primary"> <i class="fas fa-paper-plane"> </i> Submit</button>
                                    
                                    </form>
                                  

                            </div>
                        </div>
                    </div>
                </main>
              <?= $this->include('satker/partials/footer'); ?>
            </div>
        </div>
        <?= $this->include('satker/partials/js'); ?>
    </body>
</html>
