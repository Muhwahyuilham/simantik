<!DOCTYPE html>
<html lang="en">
    <!-- Header -->
   <?= $this->include('satker/partials/head') ?>

   <!-- end Header -->


    <body class="sb-nav-fixed">
       
        <!-- navbar -->
        <?= $this->include('satker/partials/navbar') ?>

        <!-- end navbar -->


        <div id="layoutSidenav">
            
            <!-- sidebar-->
            <?= $this->include('satker/partials/sidebar') ?>

            <!-- end sidebar -->


            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <div class="card">
                                <?php if(!empty(session()->getFlashdata('error'))) : ?>

                                <div class="alert alert-danger">
                                    <?php echo session()->getFlashdata('error');?>
                                </div>
                                <?php endif ?>

                            <div class="card-header">
                            <h3>TAMBAH PERMOHONAN SUPPORT</h3>
                            </div>
                            <div class="card-body">
                                
                                <form action="<?= base_url('satker/support/simpan') ?>" method="POST" enctype="multipart/form-data">
                                <?= csrf_field(); ?>                                        
                                    <div class="mb-3">
                                        <label  for="jenis_support">Jenis Support</label>
                                        <select class="form-control" name="jenis_support">
                                        <?php foreach ($jenisSupport as $js) : 
                                            echo '<option value="'.$js['id'].'">'.$js['jenis_support'].'</option>';
                                        endforeach ?>
                                        </select>
                                       
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label  for="kode_aset">Aset yang disupport</label>
                                        <select class="form-control" name="kode_aset">
                                        <?php foreach ($aplikasi as $app) : 
                                            echo '<option value="'.$app['kode_aset'].'">'.$app['kode_aset'].' - '.$app['nama_app'].'</option>';
                                        endforeach ?>
                                        </select>
                                    </div>    

                                    <div class="mb-3">
                                        <label  for="detail" class="form-label">Detail support</label>
                                        &nbsp&nbsp<div class="tooltip-sendiri"><i class="fa-sharp fa-circle-question"></i>
                                                <span class="tooltip-teks">Dijelaskan terkait permohonan support
                                                </span>
                                            </div>
                                        <textarea class="form-control" name="detail" required></textarea>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label  for="file_pendukung" class="form-label">File Pendukung (Opsional) </label>
                                        &nbsp&nbsp<div class="tooltip-sendiri"><i class="fa-sharp fa-circle-question"></i>
                                                <span class="tooltip-teks">File yang didukung .pdf .jpg .jpeg .png
                                                </span>
                                            </div>
                                        <input type="file" class="form-control" name="file_pendukung">
                                    </div> 

                                    <button type="submit" class="btn btn-primary">Submit</button>
                                    
                                    </form>
                            </div>
                        </div>
                        
                    </div>
                </main>
              <?= $this->include('satker/partials/footer'); ?>
            </div>
        </div>
        <?= $this->include('satker/partials/js'); ?>
    </body>
</html>
