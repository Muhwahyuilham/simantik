<!DOCTYPE html>
<html lang="en">
    <!-- Header -->
   <?= $this->include('satker/partials/head') ?>

   <!-- end Header -->


    <body class="sb-nav-fixed">
       
        <!-- navbar -->
        <?= $this->include('satker/partials/navbar') ?>

        <!-- end navbar -->


        <div id="layoutSidenav">
            
            <!-- sidebar-->
            <?= $this->include('satker/partials/sidebar') ?>

            <!-- end sidebar -->


            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <!-- <h2 class="mt-4">Tambah Aplikasi</h2> -->
                        <a href="<?= base_url('satker/support/permohonan')?>">
                        <button class="btn btn-danger"> Buat Permohonan </button></a>



                        <div class="card mb-4">
                            <div class="card-header">
                                <i class="fas fa-table me-1"></i>
                                PERMOHONAN SAYA
                            </div>
                            <div class="card-body">
                            <?php if(!empty(session()->getFlashdata('message'))) : ?>
                                <div class="alert alert-success">
                                    <?php echo session()->getFlashdata('message');?>
                                </div>
                                <?php endif ?>
                                <table id="datatablesSimple">
                                    <thead>
                                        <tr>
                                            <th>Nomor</th>
                                            <th>Kode Permohonan</th>
                                            <th>Tanggal Permohonan</th>
                                            <th>Jenis Support</th>
                                            <th>Aset yang disupport</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                            <th>Nomor</th>
                                            <th>Kode Permohonan</th>
                                            <th>Tanggal Permohonan</th>
                                            <th>Jenis Support</th>
                                            <th>Aset yang disupport</th>
                                            <th>Status</th>
                                        </tr>
                                    </tfoot>
                                    <tbody>
                                        <?php $n=1;
                                            foreach ($permohonanSupport as $ps) :
                                                echo "<tr> <td>".$n++."</td>";
                                                echo "<td><a href='".base_url('satker/support/detail/'.$ps->kode_request)."'>".$ps->kode_request."</a></td>";
                                                echo "<td>".$ps->created_at."</td>";
                                                echo "<td>".$ps->jenis_support."</td>";
                                                echo "<td>".$ps->nama_app."</td>";
                                                echo "<td>";
                                                if ($ps->status==0) {
                                                    echo "<span class='badge bg-warning'>Diajukan</span>";
                                                } elseif ($ps->status==1){
                                                    echo "<span class='badge bg-primary'>Diproses</span>";
                                                } else {
                                                    echo "<span class='badge bg-success'>Selesai</span>";
                                                }
                                                echo "</td> </tr>";
                                                
                                                endforeach
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        
                    </div>
                </main>
              <?= $this->include('satker/partials/footer'); ?>
            </div>
        </div>
        <?= $this->include('satker/partials/js'); ?>
    </body>
</html>
