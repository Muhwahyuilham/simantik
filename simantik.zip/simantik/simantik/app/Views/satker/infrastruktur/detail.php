<!DOCTYPE html>
<html>
<head>
    <title>Detail Infrastruktur</title>
    <?php include('satker/partials/head'); ?>
</head>
<body>
    <?php include('satker/partials/modalpassword'); ?>
    <?php include('satker/partials/navbar'); ?>
    <?php include('satker/partials/sidebar'); ?>

    <div class="container">
        <h1>Detail Infrastruktur</h1>
        <form>
            <div class="form-group">
                <label for="kode_aset">Kode Aset:</label>
                <input type="text" class="form-control" id="kode_aset" value="<?php echo $alldata['kode_aset']; ?>" readonly>
            </div>

            <div class="form-group">
                <label for="jenis_infra">Jenis Infrastruktur:</label>
                <input type="text" class="form-control" id="jenis_infra" value="<?php echo $alldata['jenis_infra']; ?>" readonly>
            </div>

            <div class="form-group">
                <label for="nama_infra">Nama Infrastruktur:</label>
                <input type="text" class="form-control" id="nama_infra" value="<?php echo $alldata['nama_infra']; ?>" readonly>
            </div>

            <div class="form-group">
                <label for="desc_infra">Deskripsi Infrastruktur:</label>
                <textarea class="form-control" id="desc_infra" readonly><?php echo $alldata['desc_infra']; ?></textarea>
            </div>

            <div class="form-group">
                <label for="tipe_infra">Tipe Infrastruktur:</label>
                <input type="text" class="form-control" id="tipe_infra" value="<?php echo $alldata['tipe_infra']; ?>" readonly>
            </div>

            <div class="form-group">
                <label for="status_milik">Status Kepemilikan:</label>
                <input type="text" class="form-control" id="status_milik" value="<?php echo $alldata['status_milik']; ?>" readonly>
            </div>

            <div class="form-group">
                <label for="nama_milik">Nama Pemilik:</label>
                <input type="text" class="form-control" id="nama_milik" value="<?php echo $alldata['nama_milik']; ?>" readonly>
            </div>

            <div class="form-group">
                <label for="unit_pengelola">Unit Pengelola:</label>
                <input type="text" class="form-control" id="unit_pengelola" value="<?php echo $alldata['unit_pengelola']; ?>" readonly>
            </div>

            <div class="form-group">
                <label for="lokasi">Lokasi:</label>
                <input type="text" class="form-control" id="lokasi" value="<?php echo $alldata['lokasi']; ?>" readonly>
            </div>

            <div class="form-group">
                <label for="kap_storage">Kapasitas Storage:</label>
                <input type="number" class="form-control" id="kap_storage" value="<?php echo $alldata['kap_storage']; ?>" readonly>
            </div>

            <div class="form-group">
                <label for="biaya_cloud">Biaya Cloud:</label>
                <input type="number" class="form-control" id="biaya_cloud" value="<?php echo $alldata['biaya_cloud']; ?>" readonly>
            </div>

            <div class="form-group">
                <label for="unit_pengembangan_cloud">Unit Pengembangan Cloud:</label>
                <input type="text" class="form-control" id="unit_pengembangan_cloud" value="<?php echo $alldata['unit_pengembangan_cloud']; ?>" readonly>
            </div>

            <div class="form-group">
                <label for="metode_akses_storage">Metode Akses Storage:</label>
                <input type="text" class="form-control" id="metode_akses_storage" value="<?php echo $alldata['metode_akses_storage']; ?>" readonly>
            </div>

            <div class="form-group">
                <label for="memori_server">Memori Server:</label>
                <input type="number" class="form-control" id="memori_server" value="<?php echo $alldata['memori_server']; ?>" readonly>
            </div>

            <div class="form-group">
                <label for="processor_server">Processor Server:</label>
                <input type="text" class="form-control" id="processor_server" value="<?php echo $alldata['processor_server']; ?>" readonly>
            </div>

            <div class="form-group">
                <label for="penyimpanan_server">Penyimpanan Server:</label>
                <input type="text" class="form-control" id="penyimpanan_server" value="<?php echo $alldata['penyimpanan_server']; ?>" readonly>
            </div>

            <div class="form-group">
                <label for="valid_server">Validitas Server:</label>
                <input type="date" class="form-control" id="valid_server" value="<?php echo $alldata['valid_server']; ?>" readonly>
            </div>

            <div class="form-group">
                <label for="bw_internet">Bandwidth Internet:</label>
                <input type="number" class="form-control" id="bw_internet" value="<?php echo $alldata['bw_internet']; ?>" readonly>
            </div>

            <div class="form-group">
                <label for="bw_intranet">Bandwidth Intranet:</label>
                <input type="number" class="form-control" id="bw_intranet" value="<?php echo $alldata['bw_intranet']; ?>" readonly>
            </div>

            <div class="form-group">
                <label for="tier">Tier:</label>
                <input type="number" class="form-control" id="tier" value="<?php echo $alldata['tier']; ?>" readonly>
            </div>

            <div class="form-group">
                <label for="pengamanan_dc">Pengamanan Data Center:</label>
                <input type="text" class="form-control" id="pengamanan_dc" value="<?php echo $alldata['pengamanan_dc']; ?>" readonly>
            </div>

            <div class="form-group">
                <label for="status_infra">Status Infrastruktur:</label>
                <input type="number" class="form-control" id="status_infra" value="<?php echo $alldata['status_infra']; ?>" readonly>
            </div>

            <div class="form-group">
                <label for="arsitektur_infra">Arsitektur Infrastruktur:</label>
                <input type="text" class="form-control" id="arsitektur_infra" value="<?php echo $alldata['arsitektur_infra']; ?>" readonly>
            </div>
        </form>
    </div>

    <?php include('satker/partials/footer'); ?>
    <?php include('satker/partials/js'); ?>
</body>
</html>
