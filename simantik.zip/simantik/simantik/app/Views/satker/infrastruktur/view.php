<!DOCTYPE html>
<html lang="en">
    <!-- Header -->
   <?= $this->include('satker/partials/head') ?>

   <!-- end Header -->


    <body class="sb-nav-fixed">
       
        <!-- navbar -->
        <?= $this->include('satker/partials/navbar') ?>

        <!-- end navbar -->


        <div id="layoutSidenav">
            
            <!-- sidebar-->
            <?= $this->include('satker/partials/sidebar') ?>

            <!-- end sidebar -->


            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <!-- <h1 class="mt-4">Dashboard</h1> -->
                        <!-- <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Aplikasi</li>
                        </ol> -->

    <div class="container">
        <div class="card mb-4">
            <div class="card-header">
                <i class="fas fa-table me-1"></i>
                Data Infrastruktur <?php
                    if(isset($status_app)) {
                        if($status_app == 0){echo('Aktif');}
                        elseif($status_app==1){echo('Suspend');}
                        elseif($status_app==2){echo('Perbaikan');}
                        elseif($status_app==3){echo('Tidak Aktif');}
                        elseif($status_app==4){echo('Dimusnahkan');}
                        else{echo('All');}
                    } else {
                        echo('All');
                    }
                ?>
            </div>
            <div class="card-body">
                <?php if(session()->getFlashdata('message')): ?>
                    <div class="alert alert-success">
                        <?= session()->getFlashdata('message'); ?>
                    </div>
                <?php endif; ?>
                <?php if(session()->getFlashdata('errormessage')): ?>
                    <div class="alert alert-danger">
                        <?= session()->getFlashdata('errormessage'); ?>
                    </div>
                <?php endif; ?>

                <div class="card-body">
                <table id="datatablesSimple">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Infrastruktur</th>
                            <th>Deskripsi</th>
                            <th>Tipe Infrastruktur</th>
                            <th>Status Milik</th>
                            <th>Nama Pemilik</th>
                            <th>Unit Pengelola</th>
                            <th>Lokasi</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $no = 1;
                        foreach($alldata as $key => $perdata) : 
                        ?>
                        <tr>
                            <td><?php echo ($no++) ?></td>
                            <td><?php echo $perdata['nama_infra'] ?></td>
                            <td><?php echo $perdata['desc_infra'] ?></td>
                            <td><?php echo $perdata['tipe_infra'] ?></td>
                            <td><?php echo $perdata['status_milik'] ? 'Milik' : 'Sewa' ?></td>
                            <td><?php echo $perdata['nama_milik'] ?></td>
                            <td><?php echo $perdata['unit_pengelola'] ?></td>
                            <td><?php echo $perdata['lokasi'] ?></td>
                            <td class="text-center">
                                <a href="<?php echo base_url('infrastruktur/detail/'.$perdata['kode_aset']) ?>" class="btn btn-sm btn-primary"> <i class="fas fa-info"> </i></a>
                                <a href="<?php echo base_url('infrastruktur/edit/'.$perdata['kode_aset']) ?>" class="btn btn-sm btn-warning"><i class="fas fa-edit"></i></a>
                                <!-- <a href="<?php echo base_url('infrastruktur/delete/'.$perdata['kode_aset']) ?>" class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></a> -->
                            </td>
                        </tr>
                        <?php endforeach ?>
                        </tbody>

                                </table>
                            </div>
                        </div>
                    </div>
                </main>
              <?= $this->include('satker/partials/footer'); ?>
                        </div>
            </div>
        </div>

        <?= $this->include('satker/partials/js'); ?>

    </body>
</html>

