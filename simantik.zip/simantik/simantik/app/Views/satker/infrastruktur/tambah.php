<!DOCTYPE html>
<html lang="en">
    <!-- Header -->
 
   <?= $this->include('satker/partials/head') ?>
   

   <!-- end Header -->


    <body class="sb-nav-fixed">
       
        <!-- navbar -->
        <?= $this->include('satker/partials/navbar') ?>

        <!-- end navbar -->


        <div id="layoutSidenav">
            
            <!-- sidebar-->
            <?= $this->include('satker/partials/sidebar') ?>

            <!-- end sidebar -->

            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
        <h1>Tambah Infrastruktur</h1>
        <?php if(session()->getFlashdata('message')): ?>
            <div class="alert alert-success">
                <?= session()->getFlashdata('message'); ?>
            </div>
        <?php endif; ?>

        <form action="<?php echo base_url('satker/infrastruktur/store'); ?>" method="post">
        <div class="mb-3">
            <label  class="form-label">Nama Infrastruktur</label>
            <input type="text" class="form-control" name="nama_app" required>
        </div>

            <div class="mb-3">
            <label class="form-label">Deskripsi Infrastruktur</label>
                 &nbsp&nbsp<div class="tooltip-sendiri"><i class="fa-sharp fa-circle-question"></i>
                <span class="tooltip-teks">Uraikan definisi dari aplikasi</span>
            </div>
            <textarea class="form-control" name="desc_app" rows="3" required></textarea>
            </div>

            <div class="form-group">
                <label for="tipe_infra">Tipe Infrastruktur:</label>
                <input type="text" class="form-control" name="tipe_infra" id="tipe_infra" required>
            </div>

            <div class="form-group">
                <label for="status_milik">Status Kepemilikan:</label>
                <input type="text" class="form-control" name="status_milik" id="status_milik" required>
            </div>

            <div class="form-group">
                <label for="nama_milik">Nama Pemilik:</label>
                <input type="text" class="form-control" name="nama_milik" id="nama_milik" required>
            </div>

            <div class="form-group">
                <label for="unit_pengelola">Unit Pengelola:</label>
                <input type="text" class="form-control" name="unit_pengelola" id="unit_pengelola" required>
            </div>

            <div class="form-group">
                <label for="lokasi">Lokasi:</label>
                <input type="text" class="form-control" name="lokasi" id="lokasi" required>
            </div>

            <div class="form-group">
                <label for="kap_storage">Kapasitas Storage:</label>
                <input type="number" class="form-control" name="kap_storage" id="kap_storage" required>
            </div>

            <div class="form-group">
                <label for="biaya_cloud">Biaya Cloud:</label>
                <input type="number" class="form-control" name="biaya_cloud" id="biaya_cloud" required>
            </div>

            <div class="form-group">
                <label for="unit_pengembangan_cloud">Unit Pengembangan Cloud:</label>
                <input type="text" class="form-control" name="unit_pengembangan_cloud" id="unit_pengembangan_cloud" required>
            </div>

            <div class="form-group">
                <label for="metode_akses_storage">Metode Akses Storage:</label>
                <input type="text" class="form-control" name="metode_akses_storage" id="metode_akses_storage" required>
            </div>

            <div class="form-group">
                <label for="memori_server">Memori Server:</label>
                <input type="number" class="form-control" name="memori_server" id="memori_server" required>
            </div>

            <div class="form-group">
                <label for="processor_server">Processor Server:</label>
                <input type="text" class="form-control" name="processor_server" id="processor_server" required>
            </div>

            <div class="form-group">
                <label for="penyimpanan_server">Penyimpanan Server:</label>
                <input type="text" class="form-control" name="penyimpanan_server" id="penyimpanan_server" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Tipe Lisensi</label>
                <select class="form-control" name="license_type" required>
                <option value="Terbuka/Open Source">Terbuka/Open Source</option>
                <option value="Tertutup/Berbayar">Tertutup/Berbayar</option>
                </select>
            </div>

            <div class="form-group">
                <label for="valid_server">Validitas Server:</label>
                <input type="date" class="form-control" name="valid_server" id="valid_server" required>
            </div>

            <div class="form-group">
                <label for="bw_internet">Bandwidth Internet:</label>
                <input type="number" class="form-control" name="bw_internet" id="bw_internet" required>
            </div>

            <div class="form-group">
                <label for="bw_intranet">Bandwidth Intranet:</label>
                <input type="number" class="form-control" name="bw_intranet" id="bw_intranet" required>
            </div>

            <div class="form-group">
                <label for="tier">Tier:</label>
                <input type="number" class="form-control" name="tier" id="tier" required>
            </div>

            <div class="form-group">
                <label for="pengamanan_dc">Pengamanan Data Center:</label>
                <input type="text" class="form-control" name="pengamanan_dc" id="pengamanan_dc" required>
            </div>

            <div class="form-group">
                <label for="status_infra">Status Infrastruktur:</label>
                <input type="number" class="form-control" name="status_infra" id="status_infra" required>
            </div>

            <div class="form-group">
                <label for="arsitektur_infra">Arsitektur Infrastruktur:</label>
                <input type="text" class="form-control" name="arsitektur_infra" id="arsitektur_infra" required>
            </div>
            <div class="d-grid col-3 mx-auto">
                        <button type="submit" class="btn btn-primary"> <i class="fas fa-paper-plane"> </i> Submit</button>
            </div>

        </form>
        </div>
             </main>
              <?= $this->include('satker/partials/footer'); ?>
            </div>
    </div>

    <?= $this->include('satker/partials/js'); ?>
</body>
</html>
