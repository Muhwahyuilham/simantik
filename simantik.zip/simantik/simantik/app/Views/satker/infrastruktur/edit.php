<!DOCTYPE html>
<html>
<head>
    <title>Edit Infrastruktur</title>
    <?php include('satker/partials/head'); ?>
</head>
<body>
    <?php include('satker/partials/modalpassword'); ?>
    <?php include('satker/partials/navbar'); ?>
    <?php include('satker/partials/sidebar'); ?>

    <div class="container">
        <h1>Edit Infrastruktur</h1>
        <?php if(session()->getFlashdata('message')): ?>
            <div class="alert alert-success">
                <?= session()->getFlashdata('message'); ?>
            </div>
        <?php endif; ?>

        <form action="<?php echo base_url('satker/infrastruktur/update'); ?>" method="post">
            <input type="hidden" name="kode_aset" value="<?php echo $alldata['kode_aset']; ?>">

            <div class="form-group">
                <label for="jenis_infra">Jenis Infrastruktur:</label>
                <input type="text" class="form-control" name="jenis_infra" id="jenis_infra" value="<?php echo $alldata['jenis_infra']; ?>" required>
            </div>

            <div class="form-group">
                <label for="nama_infra">Nama Infrastruktur:</label>
                <input type="text" class="form-control" name="nama_infra" id="nama_infra" value="<?php echo $alldata['nama_infra']; ?>" required>
            </div>

            <div class="form-group">
                <label for="desc_infra">Deskripsi Infrastruktur:</label>
                <textarea class="form-control" name="desc_infra" id="desc_infra" required><?php echo $alldata['desc_infra']; ?></textarea>
            </div>

            <div class="form-group">
                <label for="tipe_infra">Tipe Infrastruktur:</label>
                <input type="text" class="form-control" name="tipe_infra" id="tipe_infra" value="<?php echo $alldata['tipe_infra']; ?>" required>
            </div>

            <div class="form-group">
                <label for="status_milik">Status Kepemilikan:</label>
                <input type="text" class="form-control" name="status_milik" id="status_milik" value="<?php echo $alldata['status_milik']; ?>" required>
            </div>

            <div class="form-group">
                <label for="nama_milik">Nama Pemilik:</label>
                <input type="text" class="form-control" name="nama_milik" id="nama_milik" value="<?php echo $alldata['nama_milik']; ?>" required>
            </div>

            <div class="form-group">
                <label for="unit_pengelola">Unit Pengelola:</label>
                <input type="text" class="form-control" name="unit_pengelola" id="unit_pengelola" value="<?php echo $alldata['unit_pengelola']; ?>" required>
            </div>

            <div class="form-group">
                <label for="lokasi">Lokasi:</label>
                <input type="text" class="form-control" name="lokasi" id="lokasi" value="<?php echo $alldata['lokasi']; ?>" required>
            </div>

            <div class="form-group">
                <label for="kap_storage">Kapasitas Storage:</label>
                <input type="number" class="form-control" name="kap_storage" id="kap_storage" value="<?php echo $alldata['kap_storage']; ?>" required>
            </div>

            <div class="form-group">
                <label for="biaya_cloud">Biaya Cloud:</label>
                <input type="number" class="form-control" name="biaya_cloud" id="biaya_cloud" value="<?php echo $alldata['biaya_cloud']; ?>" required>
            </div>

            <div class="form-group">
                <label for="unit_pengembangan_cloud">Unit Pengembangan Cloud:</label>
                <input type="text" class="form-control" name="unit_pengembangan_cloud" id="unit_pengembangan_cloud" value="<?php echo $alldata['unit_pengembangan_cloud']; ?>" required>
            </div>

            <div class="form-group">
                <label for="metode_akses_storage">Metode Akses Storage:</label>
                <input type="text" class="form-control" name="metode_akses_storage" id="metode_akses_storage" value="<?php echo $alldata['metode_akses_storage']; ?>" required>
            </div>

            <div class="form-group">
                <label for="memori_server">Memori Server:</label>
                <input type="number" class="form-control" name="memori_server" id="memori_server" value="<?php echo $alldata['memori_server']; ?>" required>
            </div>

            <div class="form-group">
                <label for="processor_server">Processor Server:</label>
                <input type="text" class="form-control" name="processor_server" id="processor_server" value="<?php echo $alldata['processor_server']; ?>" required>
            </div>

            <div class="form-group">
                <label for="penyimpanan_server">Penyimpanan Server:</label>
                <input type="text" class="form-control" name="penyimpanan_server" id="penyimpanan_server" value="<?php echo $alldata['penyimpanan_server']; ?>" required>
            </div>

            <div class="form-group">
                <label for="valid_server">Validitas Server:</label>
                <input type="date" class="form-control" name="valid_server" id="valid_server" value="<?php echo $alldata['valid_server']; ?>" required>
            </div>

            <div class="form-group">
                <label for="bw_internet">Bandwidth Internet:</label>
                <input type="number" class="form-control" name="bw_internet" id="bw_internet" value="<?php echo $alldata['bw_internet']; ?>" required>
            </div>

            <div class="form-group">
                <label for="bw_intranet">Bandwidth Intranet:</label>
                <input type="number" class="form-control" name="bw_intranet" id="bw_intranet" value="<?php echo $alldata['bw_intranet']; ?>" required>
            </div>

            <div class="form-group">
                <label for="tier">Tier:</label>
                <input type="number" class="form-control" name="tier" id="tier" value="<?php echo $alldata['tier']; ?>" required>
            </div>

            <div class="form-group">
                <label for="pengamanan_dc">Pengamanan Data Center:</label>
                <input type="text" class="form-control" name="pengamanan_dc" id="pengamanan_dc" value="<?php echo $alldata['pengamanan_dc']; ?>" required>
            </div>

            <div class="form-group">
                <label for="status_infra">Status Infrastruktur:</label>
                <input type="number" class="form-control" name="status_infra" id="status_infra" value="<?php echo $alldata['status_infra']; ?>" required>
            </div>

            <div class="form-group">
                <label for="arsitektur_infra">Arsitektur Infrastruktur:</label>
                <input type="text" class="form-control" name="arsitektur_infra" id="arsitektur_infra" value="<?php echo $alldata['arsitektur_infra']; ?>" required>
            </div>

            <button type="submit" class="btn btn-primary">Simpan</button>
        </form>
    </div>

    <?php include('satker/partials/footer'); ?>
    <?php include('satker/partials/js'); ?>
</body>
</html>
