<!DOCTYPE html>
<html lang="en">
    <!-- Header -->
   <?= $this->include('satker/partials/head') ?>

   <!-- end Header -->


    <body class="sb-nav-fixed">
       
        <!-- navbar -->
        <?= $this->include('satker/partials/navbar') ?>

        <!-- end navbar -->


        <div id="layoutSidenav">
            
            <!-- sidebar-->
            <?= $this->include('satker/partials/sidebar') ?>

            <!-- end sidebar -->


            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <!-- <h1 class="mt-4">Dashboard</h1> -->
                        <!-- <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Aplikasi</li>
                        </ol> -->

                        
                        <div class="card mb-4">
                            <div class="card-header">
                                <i class="fas fa-table me-1"></i>
                                Data Aplikasi <?php
                                                    if($status_app == 0){echo('Aktif');}
                                                    elseif($status_app==1){echo('Suspend');}
                                                    elseif($status_app==2){echo('Perbaikan');}
                                                    elseif($status_app==3){echo('Tidak Aktif');}
                                                    elseif($status_app==4){echo('Dimusnahkan');}
                                                    else{echo('All');}
                                                    ?>
                            </div>
                            <?php if(!empty(session()->getFlashdata('message'))) : ?>

                            <div class="alert alert-success">
                                <?php echo session()->getFlashdata('message');?>
                            </div>
                                
                            <?php endif ?>

                            <?php if(!empty(session()->getFlashdata('errormessage'))) : ?>

                            <div class="alert alert-danger">
                                <?php echo session()->getFlashdata('errormessage');?>
                            </div>
                                
                            <?php endif ?>

                            <div class="card-body">
                                <table id="datatablesSimple">
                                    <thead>
                                        <tr>
                                            <th>No </th>
                                            <th>Kode<br>Aset</th>
                                            <th>Arsitektur<br>Probis</th>
                                            <th>Arsitektur<br>Aplikasi </th> 
                                            <th>Satker</th>
                                            <th>Nama<br>Aplikasi</th>
                                           
                                            <th>Basis</th>
                                            <th>Domain</th>
                                            <th>Tahun</th>
                                            <th>Status<br>Aplikasi</th>
                                            <th>Aksi</th>




                                            
                                        </tr>
                                    </thead>
                                   
                                    <tbody>
                                        
                                        <?php 
                                         $no = 1;
                                        foreach($alldata as $key => $perdata) : 
                                        ?>

                                        <tr>
                                            <td><?php echo ($no++) ?></td>
                                            <td><?php echo $perdata['kode_aset'] ?></td>
                                            <td><?php echo "RAB.".$perdata['arsitektur_probis'] ?></td>
                                            <td><?php echo "RAA.".$perdata['arsitektur_app'] ?></td>

                                            <td><?php echo $perdata['nama_satker'] ?></td>
                                            <td><?php echo $perdata['nama_app'] ?></td>
                                            <td><?php echo $perdata['basis_app'] ?></td>
                                            <td><?php echo $perdata['url_app'] ?></td>
                                            <td><?php echo $perdata['dev_year'] ?></td>
                                            <td><?php if($perdata['status_app']==0){echo ("Aktif");}
                                                      elseif($perdata['status_app']==1){echo ("Suspend");}
                                                      elseif($perdata['status_app']==2){echo ("Dalam<br>Perbaikan");}
                                                      elseif($perdata['status_app']==3){echo ("Tidak Aktif");}
                                                      else{ echo ("Dimusnahkan");} ?></td>
                                            <td class="text-center">
                                            <a href="<?php echo base_url('satker/aplikasi/detail/'.$perdata['kode_aset']) ?>" class="btn btn-sm btn-primary"> <i class="fas fa-info"> </i></a>
                                            &nbsp;<a href="<?php echo base_url('satker/aplikasi/edit/'.$perdata['kode_aset']) ?>" class="btn btn-sm btn-warning"><i class="fas fa-edit"></i></a>
                                            <!-- &nbsp;<a href="<?php echo base_url('satker/aplikasi/delete/'.$perdata['kode_aset']) ?>" class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></a> -->
                                            </td>
                                        </tr>

                                        <?php endforeach ?>
                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </main>
              <?= $this->include('satker/partials/footer'); ?>
            </div>
        </div>

        <?= $this->include('satker/partials/js'); ?>

    </body>
</html>
