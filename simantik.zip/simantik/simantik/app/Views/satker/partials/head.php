<head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title> <?php 
                        $request = service('request');
                        $uri = $request->uri;
                        $something = $uri->getSegment(2);
                        if($something=='aplikasi'){echo 'Aplikasi';}
                        elseif($something=='profile'){echo ('Profile');}
                        else{echo ('Dashboard');}
                                ?>- SIMANTIK</title>
                                
        <style>
                .tooltip-sendiri {
                position: relative;
                display: inline-block;
                }

                .tooltip-sendiri .tooltip-teks {
                visibility: hidden;
                padding: 0.25em 0.5em;
                background-color: #212529;
                color: #fff;
                text-align: left;
                border-radius: 0.25em;
                white-space: nowrap;
                
                /* Position the tooltip */
                position: absolute;
                z-index: 1;
                }

                .tooltip-sendiri:hover .tooltip-teks {
                visibility: visible;
                }
        </style>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
        <link href="<?= base_url('sbadmin/css/styles.css') ?>" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
        <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
        

</head>

<!-- Modal -->
<?= $this->include('satker/partials/modalpassword') ?>

<!-- end Modal -->

