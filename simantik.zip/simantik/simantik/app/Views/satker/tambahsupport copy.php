<!DOCTYPE html>
<html lang="en">
    <!-- Header -->
   <?= $this->include('satker/partials/head') ?>

   <!-- end Header -->


    <body class="sb-nav-fixed">
       
        <!-- navbar -->
        <?= $this->include('satker/partials/navbar') ?>

        <!-- end navbar -->


        <div id="layoutSidenav">
            
            <!-- sidebar-->
            <?= $this->include('satker/partials/sidebar') ?>

            <!-- end sidebar -->


            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <!-- <h2 class="mt-4">Tambah Aplikasi</h2> -->
                        
                        
                        <div class="card">
                            <div class="card-header">
                            TAMBAH PERMOHOANAN SUPPORT
                            </div>
                            <div class="card-body">
                                <?php if(!empty(session()->getFlashdata('message'))) : ?>

                                <div class="alert alert-success">
                                    <?php echo session()->getFlashdata('message');?>
                                </div>
                                <?php endif ?>
                                    
                                <?php if(!empty(session()->getFlashdata('error'))) : ?>

                                <div class="alert alert-danger">
                                    <?php echo session()->getFlashdata('error');?>
                                </div>
                                <?php endif ?>

                                <form action="<?= base_url('satker/support/simpan') ?>" method="POST" enctype="multipart/form-data">
                                <?= csrf_field(); ?>    
                                <input name="user_id" type="hidden" value="1" />
                                    
                                    <div class="mb-3">
                                        <label  for="jenis_support">Jenis Support</label>
                                        <select class="form-control" name="jenis_support">
                                        <?php foreach ($jenisSupport as $js) : 
                                            echo '<option value="'.$js['id'].'">'.$js['jenis_support'].'</option>';
                                        endforeach ?>
                                        </select>
                                       
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label  for="kode_aset">Aset yang disupport</label>
                                        <select class="form-control" name="kode_aset">
                                        <?php foreach ($aplikasi as $app) : 
                                            echo '<option value="'.$app['kode_aset'].'">'.$app['kode_aset'].' - '.$app['nama_app'].'</option>';
                                        endforeach ?>
                                        </select>
                                    </div>    

                                    <div class="mb-3">
                                        <label  for="detail" class="form-label">Detail support</label>
                                        <textarea class="form-control" name="detail"></textarea>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label  for="file_pendukung" class="form-label">Detail support</label>
                                        <input type="file" class="form-control" name="file_pendukung">
                                    </div> 

                                    <button type="submit" class="btn btn-primary">Submit</button>
                                    
                                    </form>
                            </div>
                        </div>




                        <div class="card mb-4">
                            <div class="card-header">
                                <i class="fas fa-table me-1"></i>
                                DAFTAR PERMOHONAN SUPPORT
                            </div>
                            <div class="card-body">
                                <table id="datatablesSimple">
                                    <thead>
                                        <tr>
                                            <th>Nomor</th>
                                            <th>Kode Permohonan</th>
                                            <th>Jenis Support</th>
                                            <th>Aset yang disupport</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                            <th>Nomor</th>
                                            <th>Kode Permohonan</th>
                                            <th>Jenis Support</th>
                                            <th>Aset yang disupport</th>
                                            <th>Status</th>
                                        </tr>
                                    </tfoot>
                                    <tbody>
                                        <?php $n=1;
                                            foreach ($permohonanSupport as $ps) :
                                                echo "<tr> <td>".$n++."</td>";
                                                echo "<td>".$ps['kode_request']."</td>";
                                                echo "<td>".$ps['id_jenis_support']."</td>";
                                                echo "<td>".$ps['kode_aset']."</td>";
                                                echo "<td>".$status = $ps['is_close'] ? '<span class="badge bg-success">Selesai</span>' : '<span class="badge bg-warning">Diajukan</span>'."</td> </tr>";
                                                
                                                endforeach
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        
                    </div>
                </main>
              <?= $this->include('satker/partials/footer'); ?>
            </div>
        </div>
        <?= $this->include('satker/partials/js'); ?>
    </body>
</html>
