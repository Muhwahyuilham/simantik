<?php 
namespace App\Models;

use CodeIgniter\Model;


class JenisSupportModel extends Model
{

    
    /**
     * table name
     */
    protected $table = "tb_jenis_support";

    /**
     * allowed Field
     */
    protected $allowedFields = [
        'jenis_support',
        'created_at',
        'updated_at'
    ];

}