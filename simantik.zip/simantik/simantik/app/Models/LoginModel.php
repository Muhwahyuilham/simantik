<?php 
namespace App\Models;

use CodeIgniter\Model;


class LoginModel extends Model
{

    
    /**
     * table name
     */
    protected $table = "tb_user";

    /**
     * allowed Field
     */
    protected $allowedFields = [
        'nama',
        'email',
        'password',
        'no_wa',
        'nama_satker',
        'role',
        'created_at',
        'updated_at'

    ];

}