<?php

namespace   App\Models;

use CodeIgniter\Model;

class InfrastrukturModel extends Model
{


    /**
     * table name
     */
    protected $table = "tb_infrastruktur";  

    /**
     * Allowed Field
     */
    protected $allowedFields = [
        'kode_aset',
        'nama_satker',
        'jenis_infra',
        'nama_infra',
        'desc_infra',
        'tipe_infra',
        'status_milik',
        'nama_milik',
        'unit_pengelola',
        'lokasi',
        'kap_storage',
        'biaya_cloud',
        'unit_pengembang_cloud',
        'metode_akses_storage',
        'penggunaan_server',
        'memori_server',
        'processor_server',
        'penyimpanan_server',
        'jenis_lisensi',
        'valid_lisensi',
        'bw_internet',
        'bw_intranet',
        'tier',
        'pengamanan_dc',
        'status_infra',
        'arsitektur_infra',
        'created_at',
        'update_at'


    ];
}
?>