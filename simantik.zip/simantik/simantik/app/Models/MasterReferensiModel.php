<?php 
namespace App\Models;

use CodeIgniter\Model;


class MasterReferensiModel extends Model
{

    
    /**
     * table name
     */
    protected $table = "m_referensi_arsitektur";

    /**
     * allowed Field
     */
    protected $allowedFields = [
        'kode_referensi',
        'nama_referensi',
        'level',
    ];

}