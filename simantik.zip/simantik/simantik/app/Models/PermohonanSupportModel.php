<?php 
namespace App\Models;

use CodeIgniter\Model;


class PermohonanSupportModel extends Model
{

    
    /**
     * table name
     */
    protected $table = "tb_permohonan_support";

    /**
     * allowed Field
     */
    protected $allowedFields = [
        'kode_request',
        'id_jenis_support',
        'kode_aset',
        'status',
        'kode_satker',
        'created_by',
        'created_at'
    ];

}