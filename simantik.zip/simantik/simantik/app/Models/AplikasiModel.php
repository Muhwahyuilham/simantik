<?php 
namespace App\Models;

use CodeIgniter\Model;


class AplikasiModel extends Model
{

    
    /**
     * table name
     */
    protected $table = "tb_aplikasi";

    /**
     * allowed Field
     */
    protected $allowedFields = [
        'kode_aset',
        'nama_satker',
        'nama_app',
        'desc_app',
        'fungsi_app',
        'output_app',
        'basis_app',
        'url_app',
        'prog_lang',
        'prog_lang_ver',
        'db_app',
        'db_ver',
        'db_name',
        'framework',
        'framework_ver',
        'dev_model',
        'dev_unit',
        'dev_year',
        'arch_model',
        'source_code',
        'license_type',
        'sec_test',
        'hosting_app',
        'pointing_ip',
        'status_app',
        'arsitektur_app',
        'arsitektur_probis',
        'created_at',
        'updated_at'


    ];

}