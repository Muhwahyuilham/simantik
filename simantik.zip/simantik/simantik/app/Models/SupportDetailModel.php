<?php 
namespace App\Models;

use CodeIgniter\Model;


class SupportDetailModel extends Model
{

    
    /**
     * table name
     */
    protected $table = "tb_support_detail";

    /**
     * allowed Field
     */
    protected $allowedFields = [
        'kode_request',
        'detail',
        'file_pendukung',
        'created_by',
        'created_at'
    ];

}