<?php 
namespace App\Models;

use CodeIgniter\Model;


class MastersatkerModel extends Model
{

    
    /**
     * table name
     */
    protected $table = "m_satker";

    /**
     * allowed Field
     */
    protected $allowedFields = [
        'kode_satker',
        'nama_satker',
        'parent_kode',
    ];

}