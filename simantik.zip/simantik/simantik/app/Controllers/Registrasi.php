<?php

namespace App\Controllers;

use App\Models\RegistrasiModel;
use App\Models\MastersatkerModel;

use CodeIgniter\Controller;


class Registrasi extends Controller
{
    public function index()
    {
        //
        $masterSatkerModel = new MastersatkerModel();
        
        $data = array(
            'allsatker' => $masterSatkerModel->get()->getResultArray()

        );

         return view('registrasi',$data);
    }


    public function store()
    {
        //load helper form and URL
        helper(['form', 'url']);

        $regisModel = new RegistrasiModel();
        $masterSatkerModel = new MastersatkerModel();
        
       
       
         
        //define validation
        $validation = $this->validate([
            'nama' => [
                'rules'  => 'required',
                'errors' => [
                    'required' => 'Nama Tidak Boleh Kosong.'
                ]
            ],
            'email'    => [
                'rules'  => 'required',
                'errors' => [
                    'required' => 'Email Tidak Boleh Kosong'
                ]
            ],
            'no_wa'    => [
                'rules'  => 'required',
                'errors' => [
                    'required' => 'Nomor WA Tidak Boleh Kosong'
                ]
            ],

            'password'    => [
                'rules'  => 'required',
                'errors' => [
                    'required' => 'Password Tidak Boleh Kosong'
                ]
            ],
            'confirmpassword'    => [
                'rules'  => 'required',
                'errors' => [
                    'required' => 'Confirm Password Tidak Boleh Kosong'
                ]
            ],
            'nama_satker'    => [
                'rules'  => 'required',
                'errors' => [
                    'required' => 'Nama Satker Tidak Boleh Kosong'
                ]
            ],
        ]);

        if(!$validation) {

            //render view with error validation message
            $data = array(
                'allsatker' => $masterSatkerModel->get()->getResultArray()
    
            );
            return view('registrasi', [$data,
                'validation' => $this->validator
            ]);

        } else {

             //model initialize
           
            $options = [
                'cost' => 12,
            ];

            $nama = $this->request->getPost('nama');
            $email =  $this->request->getPost('email');
            $password = password_hash($this->request->getPost('password'),PASSWORD_BCRYPT,$options);
            $no_wa =  $this->request->getPost('no_wa');
            $nama_satker = $this->request->getPost('nama_satker');
            $role = $this->request->getPost('role');

           
            $count = $regisModel->where('email',$email)->countAllResults();
            $countsatker = $regisModel->where('role',1)->where('nama_satker',$nama_satker)->countAllResults();
           

            if ($count>0){

                session()->setFlashdata('message', '<font style="color: red">Email Sudah Terdaftar</font>');
                return redirect()->to(base_url('registrasi'));

            } elseif ($countsatker>0) {

                session()->setFlashdata('message', '<font style="color: red">Sudah ada yang mendaftar pada satker tersebut</font>');
                return redirect()->to(base_url('registrasi'));

            } else {

                $regisModel->insert([
                    'nama'   => $nama,
                    'email' => $email,
                    'password'   => $password,
                    'no_wa' => $no_wa,
                    'nama_satker'   =>$nama_satker,
                    'role' => $role,
    
                ]);

                session()->setFlashdata('messageregister', 'User Berhasil Registrasi');
                

                return redirect()->to(base_url('login'));


            }
            
            //insert data into database
          
            //flash message
            

           
        }

    }



}
