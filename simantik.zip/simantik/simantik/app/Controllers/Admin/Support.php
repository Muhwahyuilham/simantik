<?php

namespace App\Controllers\Admin;

use CodeIgniter\Controller;
use CodeIgniter\HTTP\Files\UploadedFile;
use App\Models\JenisSupportModel;
use App\Models\PermohonanSupportModel;
use App\Models\SupportDetailModel;
use App\Models\AplikasiModel;
use App\Models\ProfileModel;


class Support extends Controller
{

    public function index()
    {
        //
        $session = session();
        
        if($session->get('role')!=0){
    
            return redirect()->to(base_url('login'));
    
        }

        return redirect()->to(base_url('admin/support/lihat'));
    }

    public function lihat (){
        $session = session();
        
        if($session->get('role')!=0){
    
            return redirect()->to(base_url('login'));
    
        }

        $permohonanSupport = new PermohonanSupportModel();

        $permohonanSupport->select('kode_request,js.jenis_support,nama_app,status, tb_permohonan_support.created_at')
        ->join('tb_aplikasi as ap','tb_permohonan_support.kode_aset = ap.kode_aset','left')
        ->join('tb_jenis_support as js','tb_permohonan_support.id_jenis_support=js.id','left')
        ->orderBy('kode_request','DESC');
        // ->where('tb_permohonan_support.nama_satker',session()->get()['nama_satker']);
        
        $query = $permohonanSupport->get()->getResult();

        $data = array(
            'permohonanSupport' => $query
        );

        return view('admin/support/lihatsupport',$data);
    }

    public function detail (string $kode_request){
        $session = session();
        
        if($session->get('role')!=0){
    
            return redirect()->to(base_url('login'));
    
        }

        // cari data requestnya
        $permohonanSupport = new PermohonanSupportModel();

        $permohonanSupport->select('kode_request, js.jenis_support, nama_app, u.nama, status, tb_permohonan_support.created_at')
        ->join('tb_aplikasi as ap','tb_permohonan_support.kode_aset = ap.kode_aset','left')
        ->join('tb_jenis_support as js','tb_permohonan_support.id_jenis_support=js.id','left')
        ->join('tb_user as u','tb_permohonan_support.created_by=u.id','left')
        ->where('tb_permohonan_support.kode_request',$kode_request);
        //->where('tb_permohonan_support.nama_satker',session()->get()['nama_satker']);
        
        $request = $permohonanSupport->get()->getResult();
        if ($request==null){
            return redirect()->to(base_url('admin/support/lihat'));
        }
        //cari detil dari requestnya
        $supportDetail = new SupportDetailModel();
        $supportDetail->select('u.nama,u.email,detail, file_pendukung, nama, tb_support_detail.created_at')
        ->join('tb_user as u','tb_support_detail.created_by=u.id')
        ->where('kode_request',$kode_request);

        $detail = $supportDetail->get()->getResult();

        $data = array(
            'request' => $request,
            'detail' => $detail
        );

        return view('admin/support/detailsupport',$data);
    }

    public function proses (){
        $session = session();
        
        if($session->get('role')!=0){
    
            return redirect()->to(base_url('login'));
    
        }

        $kode_request = $this->request->getPost('kode_request');

        $permohonanSupport = new PermohonanSupportModel();
        $permohonanSupport->set(['status'=>1])->where('kode_request',$kode_request)->update();

        $supportDetail = new SupportDetailModel();
        $supportDetail->insert([
            'kode_request'=>$kode_request,
            'detail'=> "Permohonan Anda akan saya proses. Mohon bersabar ya",
            'created_by'=>$this->getUserIdInSession()
        ]);

        
        
        return $this->detail($kode_request);
    }

    public function simpanDetail (){
        $session = session();
        
        if($session->get('role')!=0){
    
            return redirect()->to(base_url('login'));
    
        }
        
        $selesai = $this->request->getPost('selesai'); 
        $created_by = $this->getUserIdInSession();
        $kode_request = $this->request->getPost('kode_request');
        $detail = $this->request->getPost('detail');
        $file= $this->request->getFile('file_pendukung');
        $file_pendukung ="";
        
        
        if ($file->isValid()){
            $rule = [
                'file_pendukung' => 'ext_in[file_pendukung,pdf,jpg,jpeg,png]|max_size[file_pendukung,2048]'
            ];
            
            if (!$this->validate($rule)){
                session()->setFlashdata('error', \Config\Services::validation()->getError('file_pendukung'));
                return redirect()->to(base_url('admin/support/detail/'.$kode_request));
            } else {
                    
                    $namaBaru = $kode_request."-".time().".".$file->getClientExtension();
                    $file_pendukung=WRITEPATH.$namaBaru; //prod pindah ke uploads
                    $file->move(WRITEPATH,$namaBaru);
               }
        }

        $detailModel = new SupportDetailModel();
        $detailModel->insert([
            'kode_request'=>$kode_request,
            'detail'=>$detail,
            'file_pendukung'=>$file_pendukung,
            'created_by'=>$created_by
        ]);

        $permohonanSupport = new PermohonanSupportModel();
        if ($selesai!=null){
        $permohonanSupport->set(['status'=>2])->where('kode_request',$kode_request)->update();
        }

        //session()->setFlashdata('message', 'Permohonan Support Berhasi di Buat dengan nomor permohonan '.$kode_request);
        return redirect()->to(base_url('admin/support/detail/'.$kode_request));
    }

    function getUserIdInSession (){
        $sesi = session()->get();
        $user = new ProfileModel();
        $user->select('id')
        ->where('email', $sesi["email"]);
        $userID = $user->get()->getResult();
        
        
        return $userID[0]->id;
    }

    
}
