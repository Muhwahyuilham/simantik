<?php

namespace App\Controllers\Admin;

use CodeIgniter\Controller;
use CodeIgniter\HTTP\Files\UploadedFile;
use App\Models\JenisSupportModel;
use App\Models\PermohonanSupportModel;
use App\Models\SupportDetailModel;
use App\Models\AplikasiModel;
use App\Models\ProfileModel;


class JenisSupport extends Controller
{

    public function index()
    {
        //
        $session = session();
        
        if($session->get('role')!=0){
    
            return redirect()->to(base_url('login'));
    
        }
        return redirect()->to(base_url('admin/jenissupport/lihat'));
    }

    public function lihat (){
        $session = session();
        
        if($session->get('role')!=0){
    
            return redirect()->to(base_url('login'));
    
        }

        $jenisSupport = new JenisSupportModel();

        $query = $jenisSupport->get()->getResult();

        $data = array(
            'jenisSupport' => $query
        );

        return view('admin/mjenissupport/view',$data);
    }

    public function simpan (){
        $session = session();
        
        if($session->get('role')!=0){
    
            return redirect()->to(base_url('login'));
    
        }

        $input = $this->request->getPost('jenis_support');

        $jenisSupport = new JenisSupportModel();

        $jenisSupport->insert([
            'jenis_support' => $input
        ]);

        session()->setFlashdata('message', 'Data Berhasil ditambahkan');
        return redirect()->to(base_url('admin/jenissupport/lihat'));
    }

    public function edit (){
        $session = session();
        
        if($session->get('role')!=0){
    
            return redirect()->to(base_url('login'));
    
        }

        $jenisSupport = new JenisSupportModel();

        $jenisSupport->set([
            'jenis_support' => $this->request->getPost('jenis_support')
        ])->where('id',$this->request->getPost('id_support'))->update();

        session()->setFlashdata('message', 'Data Berhasil diubah');
        return redirect()->to(base_url('admin/jenissupport/lihat'));
    }

    public function delete ($id){
        $session = session();
        
        if($session->get('role')!=0){
    
            return redirect()->to(base_url('login'));
    
        }
        
        $jenisSupport = new JenisSupportModel();

        $jenisSupport->where('id',$id)->delete();
        session()->setFlashdata('message', 'Data Berhasil dihapus');
        return redirect()->to(base_url('admin/jenissupport/lihat'));
    }
    
}
