<?php

namespace App\Controllers\Admin;


use App\Models\ProfileModel;
use CodeIgniter\Controller;

class Profile extends Controller
{
    public function index()
    {
        //


        $session = session();
        
        if($session->get('role')!=0){
    
            return redirect()->to(base_url('login'));
    
        }
       

        $profileModel = new ProfileModel();

        $data = array(
            'alldata' =>  $profileModel->where('email', $session->get('email'))->first(),
           
           

        );



        return view('admin/profile/view',$data);
    }


    public function edit($email){

        $session = session();

        
        if($session->get('role')!=0){
    
            return redirect()->to(base_url('login'));
    
        }

        $profileModel = new ProfileModel();

        $cekdata = $profileModel->where('email',$email)->countAllResults();
       
    
        if($cekdata>0) {
            $alldata = $profileModel->where('email',$email)->first();
          
            $data = array(
    
                'alldata' =>$alldata
    
            );
           // session()->setFlashdata('message', 'Data Berhasil di Update');
    
            return view('admin/profile/edit',$data);
        }else{
    
             //flash message
             session()->setFlashdata('errormessage', 'Data Tidak Ditemukan');
    
             return redirect()->to(base_url('admin/profile'));
    
        }
    }

    public function update() {
        $session = session();
        
        if($session->get('role')!=0){
    
            return redirect()->to(base_url('login'));
    
        }

        $profileModel = new ProfileModel();

        $nama = $this->request->getPost('nama');
        $email = $this->request->getPost('email');
        $no_wa = $this->request->getPost('no_wa');
        $id = $this->request->getPost('id');
        $updateData = array(
            'nama' =>$nama,
            'email'=>$email,
            'no_wa' =>$no_wa

        );

        $profileModel->set($updateData)->where('id',$id)->update();

        session()->setFlashdata('message', 'Data Berhasil di Update');

        return redirect()->to(base_url('admin/profile'));



        
    }

    public function changepwd(){

        $session = session();
       
        
        if($session->get('role')!=0){
    
            return redirect()->to(base_url('login'));
    
        }

        $profileModel = new ProfileModel();
        $options = [
            'cost' => 12,
        ];

        $password = password_hash($this->request->getPost('password'),PASSWORD_BCRYPT,$options);


        $hasil = $profileModel->set('password',$password)->where('email',$session->get('email'))->update();

        if($hasil){

            session()->setFlashdata('message', 'Berhasil Update Password');
                

            return redirect()->to(base_url('admin/profile'));

        }else{

            session()->setFlashdata('erromessage', 'Gagal Update Password');
                

            return redirect()->to(base_url('admin/profile'));


        }
       


    }

    
}
