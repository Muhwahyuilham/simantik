<?php

namespace App\Controllers\Admin;

use App\Models\AplikasiModel;
use App\Models\MasterReferensiModel;

use CodeIgniter\Controller;


class Aplikasi extends Controller
{
    public function index()
    {
        //
        $session = session();
        if($session->get('role')!=0){

            return redirect()->to(base_url('login'));

             }


        $aplikasiModel = new AplikasiModel();
       

        $data = array(
            'alldata' => $aplikasiModel->get()->getResultArray(),
            'status_app'=> "all"

        );

        


        return view('admin/aplikasi/view',$data);
    }
    public function aktif()
    {
        //
        $session = session();

        //checking role

        if($session->get('role')!=0){

            return redirect()->to(base_url('login'));

        }



        $aplikasiModel = new AplikasiModel();
        // $builder = $aplikasiModel->builder();
        

        $data = array(
            'alldata' => $aplikasiModel->where('status_app',0)->get()->getResultArray(),
            'status_app'=> 0
            

        );

        


        return view('admin/aplikasi/view',$data);
    }

    public function suspend()
    {
        //
        $session = session();
        //checking role

        if($session->get('role')!=0){

            return redirect()->to(base_url('login'));

        }
        

        $aplikasiModel = new AplikasiModel();
        
        $data = array(
            'alldata' => $aplikasiModel->where('status_app',1)->get()->getResultArray(),
            'status_app'=>1

        );

        return view('admin/aplikasi/view',$data);
    }
    public function perbaikan()
    {
        //
        $session = session();
        
        //checking role

        if($session->get('role')!=0){

            return redirect()->to(base_url('login'));

        }
        

        $aplikasiModel = new AplikasiModel();
       
        $data = array(
            'alldata' => $aplikasiModel->where('status_app',2)->get()->getResultArray(),
            'status_app' => 2

        );

        return view('admin/aplikasi/view',$data);
    }
    public function tidakaktif()
    {
        //
        $session = session();

        //checking role

        if($session->get('role')!=0){

            return redirect()->to(base_url('login'));

        }
        

        $aplikasiModel = new AplikasiModel();
        // $builder = $aplikasiModel->builder();
        $aplikasiModel->where('nama_satker',$session->get('nama_satker'));

        $data = array(
            'alldata' => $aplikasiModel->where('status_app',3)->get()->getResultArray(),
            'status_app' => 3

        );

        return view('admin/aplikasi/view',$data);
    }

    public function dimusnahkan()
    {
        //
        $session = session();

        //checking role

        if($session->get('role')!=0){

            return redirect()->to(base_url('login'));

        }
        

        $aplikasiModel = new AplikasiModel();
       

        $data = array(
            'alldata' => $aplikasiModel->where('status_app',4)->get()->getResultArray(),
            'status_app' => 4

        );

        return view('admin/aplikasi/view',$data);
    }

    

    public function detail($kode_aset){

        $session = session();

        //checking role

        if($session->get('role')!=0){

            return redirect()->to(base_url('login'));

        }


        //model initialize
        $aplikasiModel = new AplikasiModel();

        $cekdata = $aplikasiModel->where('kode_aset',$kode_aset)->countAllResults();
       

        if($cekdata>0) {
            $alldata = $aplikasiModel->where('kode_aset',$kode_aset)->first();
          
            $data = array(

                'alldata' =>$alldata

            );
            //session()->setFlashdata('message', 'Data Berhasil Dihapus');

            return view('admin/aplikasi/detail',$data);
        }else{

             //flash message
             session()->setFlashdata('errormessage', 'Data Tidak Ditemukan');
 
             return redirect()->to(base_url('admin/aplikasi'));

        }

       
   }
   public function edit($kode_aset){

    $session = session();

    //checking role

    if($session->get('role')!=0){

        return redirect()->to(base_url('login'));

    }


    //model initialize
    $aplikasiModel = new AplikasiModel();

    $cekdata = $aplikasiModel->where('kode_aset',$kode_aset)->countAllResults();
   

    if($cekdata>0) {
        $alldata = $aplikasiModel->where('kode_aset',$kode_aset)->first();
      
        $referensi = new MasterReferensiModel();

      
        $data = array(

            'alldata' =>$alldata,
            'referensi' => $referensi->get()->getResult(),
            'arsitektur_app' => array(
                'level1' => substr($alldata['arsitektur_app'],0,2),
                'level2' => substr($alldata['arsitektur_app'],3,2),
                'level3' => substr($alldata['arsitektur_app'],6,2)
            )

        );

        return view('admin/aplikasi/edit',$data);
    }else{

         //flash message
         session()->setFlashdata('errormessage', 'Data Tidak Ditemukan');

         return redirect()->to(base_url('admin/aplikasi'));

    }

   
}


public function update() {

    $session = session();

    //checking role

    if($session->get('role')!=0){

        return redirect()->to(base_url('login'));

    }
    
    $aplikasiModel = new AplikasiModel();
    
  
    $kode_aset = $this->request->getPost('kode_aset');
    $status_app = $this->request->getPost('status_app');
  
    $nama_app = $this->request->getPost('nama_app');
    $desc_app = $this->request->getPost('desc_app');
    $basis_app = $this->request->getPost('basis_app');
    $url_app = $this->request->getPost('url_app');
    $prog_lang = $this->request->getPost('prog_lang');
    $prog_lang_ver =  $this->request->getPost('prog_lang_ver');
    $db_app = $this->request->getPost('db_app');
    $db_ver =  $this->request->getPost('db_ver');
    $framework=  $this->request->getPost('framework');
    $framework_ver =  $this->request->getPost('framework_ver');
    $dev_model =  $this->request->getPost('dev_model');
    $dev_year =  $this->request->getPost('dev_year');
    $source_code =  $this->request->getPost('source_code');

    $hosting_app =  $this->request->getPost('hosting_app');
    $pointing_ip =  $this->request->getPost('pointing_ip');

    
    $arch_model =  $this->request->getPost('arch_model');

    


        
        // $data = $aplikasiModel->where('kode_aset',$kode_aset)->countAllResults();
        // echo($data);

        $updateData = [
            
            
                'nama_app' => $nama_app,
                'desc_app' => $desc_app,
                'basis_app' => $basis_app,
                'url_app'=> $url_app,
                'prog_lang' => $prog_lang,
                'prog_lang_ver' => $prog_lang_ver,
                'db_app' => $db_app,
                'db_ver' => $db_ver,
                'framework' => $framework,
                'framework_ver' => $framework_ver,
                'dev_model' => $dev_model,
                'dev_year' => $dev_year,
                'source_code' => $source_code,
                'hosting_app' => $hosting_app,
                'pointing_ip' => $pointing_ip,
                
                'arch_model' => $arch_model,
                'status_app' => $status_app
                
    
            
        ];
        $aplikasiModel->set($updateData)->where('kode_aset',$kode_aset)->update();

        session()->setFlashdata('message', 'Data Aset Berhasi di Update');
        

        return redirect()->to(base_url('admin/aplikasi'));
    
    
}






   

    public function delete($kode_aset){

        $session = session();

        //checking role
    
        if($session->get('role')!=0){
    
            return redirect()->to(base_url('login'));
    
        }
         //model initialize
         $aplikasiModel = new AplikasiModel();

         $cekdata = $aplikasiModel->where('kode_aset',$kode_aset)->countAllResults();
       
 
         if($cekdata>0) {
            $aplikasiModel->where('kode_aset',$kode_aset);
             $aplikasiModel->delete();
 
             //flash message
             session()->setFlashdata('message', 'Data Berhasil Dihapus');
 
             return redirect()->to(base_url('admin/aplikasi'));
         }



        
    }


    

    
}
