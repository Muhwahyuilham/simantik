<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\AplikasiModel;


class Home extends BaseController
{
    
   

    public function index()
    {   $session = session();
        
        //checking role

        if($session->get('role')!=0){

            return redirect()->to(base_url('login'));

             }


        $aplikasiModel = new AplikasiModel();

        $data = array(
            'aktif'=> $aplikasiModel->where('status_app',0)->countAllResults(),
            'suspend'=>$aplikasiModel->where('status_app',1)->countAllResults(),
            'dalamperbaikan'=> $aplikasiModel->where('status_app',2)->countAllResults(),
            'tidakaktif'=>$aplikasiModel->where('status_app',3)->countAllResults(),
            'dimusnahkan'=>$aplikasiModel->where('status_app',4)->countAllResults(),


        );


        return view('admin/index',$data);
    }

    
}
