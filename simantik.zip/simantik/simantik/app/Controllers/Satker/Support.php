<?php

namespace App\Controllers\Satker;

use CodeIgniter\Controller;
use CodeIgniter\HTTP\Files\UploadedFile;
use App\Models\JenisSupportModel;
use App\Models\PermohonanSupportModel;
use App\Models\SupportDetailModel;
use App\Models\AplikasiModel;
use App\Models\ProfileModel;


class Support extends Controller
{

    public function index()
    {
        //
        $session = session();
        
        if($session->get('role')!=1){
    
            return redirect()->to(base_url('login'));
    
        }
        return redirect()->to(base_url('satker/support/lihat'));
    }

    public function lihat (){
        $session = session();
        
        if($session->get('role')!=1){
    
            return redirect()->to(base_url('login'));
    
        }
        
        $permohonanSupport = new PermohonanSupportModel();

        $permohonanSupport->select('kode_request,js.jenis_support,nama_app,status, tb_permohonan_support.created_at')
        ->join('tb_aplikasi as ap','tb_permohonan_support.kode_aset = ap.kode_aset','left')
        ->join('tb_jenis_support as js','tb_permohonan_support.id_jenis_support=js.id','left')
        ->where('tb_permohonan_support.nama_satker',session()->get()['nama_satker']);
        
        $query = $permohonanSupport->get()->getResult();

        $data = array(
            'permohonanSupport' => $query
        );

        return view('satker/support/lihatsupport',$data);
    }

    public function permohonan (){
        $session = session();
        
        if($session->get('role')!=1){
    
            return redirect()->to(base_url('login'));
    
        }
        
        $jenisSupport = new JenisSupportModel();
        $aplikasi = new AplikasiModel();
        
        $data = array(
            'jenisSupport' => $jenisSupport->findAll(),
            'aplikasi' => $aplikasi->where('nama_satker', session()->get()['nama_satker'])->findAll(), //where kode satker sama dengan waktu login
        );

        return view('satker/support/tambahsupport',$data);
    }

    public function simpan (){
        $session = session();
        
        if($session->get('role')!=1){
    
            return redirect()->to(base_url('login'));
    
        }
            
        $created_by = $this->getUserIdInSession();
        $jenis_support = $this->request->getPost('jenis_support');
        $kode_aset = $this->request->getPost('kode_aset');
        $detail = $this->request->getPost('detail');
        $file= $this->request->getFile('file_pendukung');
        $file_pendukung ="";
        $kode_request = $this->generateKodeRequest();
        
        if ($file->isValid()){
            $rule = [
                'file_pendukung' => 'ext_in[file_pendukung,pdf,jpg,jpeg,png]|max_size[file_pendukung,2048]'
            ];
            
            if (!$this->validate($rule)){
                session()->setFlashdata('error', \Config\Services::validation()->getError('file_pendukung'));
                return redirect()->to(base_url('satker/support/permohonan'));
            } else {
                    
                    $namaBaru = $kode_request."-".time().".".$file->getClientExtension();
                    $file_pendukung=WRITEPATH.$namaBaru; //prod pindah ke uploads
                    $file->move(WRITEPATH,$namaBaru);
               }
        }

        $requestModel = new PermohonanSupportModel();
        $detailModel = new SupportDetailModel();

        $requestModel->insert([
            'kode_request'=>$kode_request,
            'id_jenis_support'=>$jenis_support,
            'kode_aset'=>$kode_aset,
            'nama_satker'=>session()->get()['nama_satker'],
            'created_by'=>$created_by
        ]);

        $detailModel->insert([
            'kode_request'=>$kode_request,
            'detail'=>$detail,
            'file_pendukung'=>$file_pendukung,
            'created_by'=>$created_by
        ]);

        session()->setFlashdata('message', 'Permohonan Support Berhasi di Buat dengan nomor permohonan '.$kode_request);
        return redirect()->to(base_url('satker/support/lihat'));
    }

    public function detail ($kode_request){
        $session = session();
        
        if($session->get('role')!=1){
    
            return redirect()->to(base_url('login'));
    
        }
        
        // cari data requestnya
        $permohonanSupport = new PermohonanSupportModel();

        $permohonanSupport->select('kode_request, js.jenis_support, nama_app, u.nama, status, tb_permohonan_support.created_at, tb_permohonan_support.nama_satker')
        ->join('tb_aplikasi as ap','tb_permohonan_support.kode_aset = ap.kode_aset','left')
        ->join('tb_jenis_support as js','tb_permohonan_support.id_jenis_support=js.id','left')
        ->join('tb_user as u','tb_permohonan_support.created_by=u.id','left')
        ->where('tb_permohonan_support.kode_request',$kode_request)
        ->where('tb_permohonan_support.nama_satker',session()->get()['nama_satker']);
        
        $request = $permohonanSupport->get()->getResult();
        if ($request==null){
            return redirect()->to(base_url('admin/support/lihat'));
        }
        // dd($request);
        
        //cari detil dari requestnya
        $supportDetail = new SupportDetailModel();
        $supportDetail->select('u.nama,u.email,detail, file_pendukung, nama, tb_support_detail.created_at')
        ->join('tb_user as u','tb_support_detail.created_by=u.id')
        ->where('kode_request',$kode_request);

        $detail = $supportDetail->get()->getResult();

        //dd($request, $detail);
        $data = array(
            'request' => $request,
            'detail' => $detail
        );

        return view('satker/support/detailsupport',$data);
    }

    public function simpanDetail (){    
        $session = session();
        
        if($session->get('role')!=1){
    
            return redirect()->to(base_url('login'));
    
        }
        
        $created_by = $this->getUserIdInSession();
        $kode_request = $this->request->getPost('kode_request');
        $detail = $this->request->getPost('detail');
        $file= $this->request->getFile('file_pendukung');
        $file_pendukung ="";
        
        
        if ($file->isValid()){
            $rule = [
                'file_pendukung' => 'ext_in[file_pendukung,pdf,jpg,jpeg,png]|max_size[file_pendukung,2048]'
            ];
            
            if (!$this->validate($rule)){
                session()->setFlashdata('error', \Config\Services::validation()->getError('file_pendukung'));
                return redirect()->to(base_url('satker/support/detail/'.$kode_request));
            } else {
                    
                    $namaBaru = $kode_request."-".time().".".$file->getClientExtension();
                    $file_pendukung=WRITEPATH.$namaBaru; //prod pindah ke uploads
                    $file->move(WRITEPATH,$namaBaru);
               }
        }
        $detailModel = new SupportDetailModel();

        $detailModel->insert([
            'kode_request'=>$kode_request,
            'detail'=>$detail,
            'file_pendukung'=>$file_pendukung,
            'created_by'=>$created_by
        ]);

        //session()->setFlashdata('message', 'Permohonan Support Berhasi di Buat dengan nomor permohonan '.$kode_request);
        return redirect()->to(base_url('satker/support/detail/'.$kode_request));
    }

    function generateKodeRequest (){
        $request = new PermohonanSupportModel();
        $num = str_pad($request->countAll()+1, 6, "0", STR_PAD_LEFT);
        return "PS".$num;
    }

    function getUserIdInSession (){
        $sesi = session()->get();
        $user = new ProfileModel();
        $user->select('id')
        ->where('email', $sesi["email"]);
        $userID = $user->get()->getResult();
        
        
        return $userID[0]->id;
    }

    function getNamabyID ($id){
        $user = new ProfileModel();
        $user->select('nama')
        ->where('id',$id);
        $nama = $user->get()->getResult();
        return $nama[0]->nama;
    }
    
}
