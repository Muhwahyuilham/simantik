<?php

namespace App\Controllers\Satker;

use App\Controllers\BaseController;
use App\Models\AplikasiModel;


class Home extends BaseController
{
    
   

    public function index()
    {   $session = session();
        $aplikasiModel = new AplikasiModel();

        $data = array(
            'aktif'=> $aplikasiModel->where('nama_satker', $session->get('nama_satker'))
                                    ->where('status_app',0)->countAllResults(),
            'suspend'=>$aplikasiModel->where('nama_satker', $session->get('nama_satker'))
                                     ->where('status_app',1)->countAllResults(),
            'dalamperbaikan'=> $aplikasiModel->where('nama_satker', $session->get('nama_satker'))
                                     ->where('status_app',2)->countAllResults(),
            'tidakaktif'=>$aplikasiModel->where('nama_satker', $session->get('nama_satker'))
                                      ->where('status_app',3)->countAllResults(),
            'dimusnahkan'=>$aplikasiModel->where('nama_satker', $session->get('nama_satker'))
                                      ->where('status_app',4)->countAllResults(),


        );


        return view('satker/index',$data);
    }

    
}
