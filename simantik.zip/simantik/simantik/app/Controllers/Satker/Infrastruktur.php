<?php
namespace App\Controllers\Satker;

use App\Models\InfrastrukturModel;
use App\Models\MasterReferensiModel;
use CodeIgniter\Controller;

class Infrastruktur extends Controller
{
    public function index()
    {
        $session = session();
        if ($session->get('role') != 1) {
            return redirect()->to(base_url('login'));
        }

        $infrastrukturModel = new InfrastrukturModel();
        $infrastrukturModel->where('nama_satker', $session->get('nama_satker'));
        $data = array(
            'alldata' => $infrastrukturModel->get()->getResultArray(),
            'status_infra' => "all"
        );

        return view('satker/infrastruktur/view', $data);
    }

    public function aktif()
    {
        $session = session();
        if ($session->get('role') != 1) {
            return redirect()->to(base_url('login'));
        }

        $infrastrukturModel = new InfrastrukturModel();
        $infrastrukturModel->where('nama_satker', $session->get('nama_satker'));
        $data = array(
            'alldata' => $infrastrukturModel->where('status_infra', 0)->get()->getResultArray(),
            'status_infra' => 0
        );

        return view('satker/infrastruktur/view', $data);
    }

    public function suspend()
    {
        $session = session();
        if ($session->get('role') != 1) {
            return redirect()->to(base_url('login'));
        }

        $infrastrukturModel = new InfrastrukturModel();
        $infrastrukturModel->where('nama_satker', $session->get('nama_satker'));
        $data = array(
            'alldata' => $infrastrukturModel->where('status_infra', 1)->get()->getResultArray(),
            'status_infra' => 1
        );

        return view('satker/infrastruktur/view', $data);
    }

    public function perbaikan()
    {
        $session = session();
        if ($session->get('role') != 1) {
            return redirect()->to(base_url('login'));
        }

        $infrastrukturModel = new InfrastrukturModel();
        $infrastrukturModel->where('nama_satker', $session->get('nama_satker'));
        $data = array(
            'alldata' => $infrastrukturModel->where('status_infra', 2)->get()->getResultArray(),
            'status_infra' => 2
        );

        return view('satker/infrastruktur/view', $data);
    }

    public function tidakaktif()
    {
        $session = session();
        if ($session->get('role') != 1) {
            return redirect()->to(base_url('login'));
        }

        $infrastrukturModel = new InfrastrukturModel();
        $infrastrukturModel->where('nama_satker', $session->get('nama_satker'));
        $data = array(
            'alldata' => $infrastrukturModel->where('status_infra', 3)->get()->getResultArray(),
            'status_infra' => 3
        );

        return view('satker/infrastruktur/view', $data);
    }

    public function dimusnahkan()
    {
        $session = session();
        if ($session->get('role') != 1) {
            return redirect()->to(base_url('login'));
        }

        $infrastrukturModel = new InfrastrukturModel();
        $infrastrukturModel->where('nama_satker', $session->get('nama_satker'));
        $data = array(
            'alldata' => $infrastrukturModel->where('status_infra', 4)->get()->getResultArray(),
            'status_infra' => 4
        );

        return view('satker/infrastruktur/view', $data);
    }

    public function tambah()
    {
        $session = session();
        if ($session->get('role') != 1) {
            return redirect()->to(base_url('login'));
        }

        $referensi = new MasterReferensiModel();
        $data = array(
            'referensi' => $referensi->get()->getResult()
        );

        return view('satker/infrastruktur/tambah', $data);
    }

    public function store()
    {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $randomString = '';

        for ($i = 0; $i < 8; $i++) {
            $index = rand(0, strlen($characters) - 1);
            $randomString .= $characters[$index];
        }

        $infrastrukturModel = new InfrastrukturModel();
        $session = session();
        if ($session->get('role') != 1) {
            return redirect()->to(base_url('login'));
        }

        $kode_aset = "INFRA" . "." . $randomString;
        $nama_satker = $session->get('nama_satker');
        $jenis_infra = $this->request->getPost('jenis_infra');
        $nama_infra = $this->request->getPost('nama_infra');
        $desc_infra = $this->request->getPost('desc_infra');
        $tipe_infra = $this->request->getPost('tipe_infra');
        $status_milik = $this->request->getPost('status_milik');
        $nama_milik = $this->request->getPost('nama_milik');
        $unit_pengelola = $this->request->getPost('unit_pengelola');
        $lokasi = $this->request->getPost('lokasi');
        $kap_storage = $this->request->getPost('kap_storage');
        $biaya_cloud = $this->request->getPost('biaya_cloud');
        $unit_pengembangan_cloud = $this->request->getPost('unit_pengembangan_cloud');
        $metode_akses_storage = $this->request->getPost('metode_akses_storage');
        $memori_server = $this->request->getPost('memori_server');
        $processor_server = $this->request->getPost('processor_server');
        $penyimpanan_server = $this->request->getPost('penyimpanan_server');
        $valid_server = $this->request->getPost('valid_server');
        $bw_internet = $this->request->getPost('bw_internet');
        $bw_intranet = $this->request->getPost('bw_intranet');
        $tier = $this->request->getPost('tier');
        $pengamanan_dc = $this->request->getPost('pengamanan_dc');
        $status_infra = $this->request->getPost('status_infra');
        $arsitektur_infra = $this->request->getPost('arsitektur_infra');

        $infrastrukturModel->insert([
            'kode_aset' => $kode_aset,
            'nama_satker' => $nama_satker,
            'jenis_infra' => $jenis_infra,
            'nama_infra' => $nama_infra,
            'desc_infra' => $desc_infra,
            'tipe_infra' => $tipe_infra,
            'status_milik' => $status_milik,
            'nama_milik' => $nama_milik,
            'unit_pengelola' => $unit_pengelola,
            'lokasi' => $lokasi,
            'kap_storage' => $kap_storage,
            'biaya_cloud' => $biaya_cloud,
            'unit_pengembangan_cloud' => $unit_pengembangan_cloud,
            'metode_akses_storage' => $metode_akses_storage,
            'memori_server' => $memori_server,
            'processor_server' => $processor_server,
            'penyimpanan_server' => $penyimpanan_server,
            'valid_server' => $valid_server,
            'bw_internet' => $bw_internet,
            'bw_intranet' => $bw_intranet,
            'tier' => $tier,
            'pengamanan_dc' => $pengamanan_dc,
            'status_infra' => $status_infra,
            'arsitektur_infra' => $arsitektur_infra,
        ]);

        session()->setFlashdata('message', 'Data Infrastruktur Berhasil Disimpan');
        return redirect()->to(base_url('satker/infrastruktur'));
    }

    public function detail($kode_aset)
    {
        $session = session();
        if ($session->get('role') != 1) {
            return redirect()->to(base_url('login'));
        }

        $infrastrukturModel = new InfrastrukturModel();
        $cekdata = $infrastrukturModel->where('kode_aset', $kode_aset)->countAllResults();

        if ($cekdata > 0) {
            $alldata = $infrastrukturModel->where('kode_aset', $kode_aset)->first();
            $data = array('alldata' => $alldata);
            return view('satker/infrastruktur/detail', $data);
        } else {
            session()->setFlashdata('errormessage', 'Data Tidak Ditemukan');
            return redirect()->to(base_url('satker/infrastruktur'));
        }
    }

    public function edit($kode_aset)
    {
        $session = session();
        if ($session->get('role') != 1) {
            return redirect()->to(base_url('login'));
        }

        $infrastrukturModel = new InfrastrukturModel();
        $cekdata = $infrastrukturModel->where('kode_aset', $kode_aset)->countAllResults();

        if ($cekdata > 0) {
            $alldata = $infrastrukturModel->where('kode_aset', $kode_aset)->first();
            $referensi = new MasterReferensiModel();

            $data = array(
                'alldata' => $alldata,
                'referensi' => $referensi->get()->getResult(),
                'arsitektur_infra' => array(
                    'level1' => substr($alldata['arsitektur_infra'], 0, 2),
                    'level2' => substr($alldata['arsitektur_infra'], 3, 2),
                    'level3' => substr($alldata['arsitektur_infra'], 6, 2)
                )
            );

            return view('satker/infrastruktur/edit', $data);
        } else {
            session()->setFlashdata('errormessage', 'Data Tidak Ditemukan');
            return redirect()->to(base_url('satker/infrastruktur'));
        }
    }

    public function update()
    {
        $infrastrukturModel = new InfrastrukturModel();
        $session = session();

        if ($session->get('role') != 1) {
            return redirect()->to(base_url('login'));
        }

        $kode_aset = $this->request->getPost('kode_aset');
        $nama_satker = $session->get('nama_satker');
        $jenis_infra = $this->request->getPost('jenis_infra');
        $nama_infra = $this->request->getPost('nama_infra');
        $desc_infra = $this->request->getPost('desc_infra');
        $tipe_infra = $this->request->getPost('tipe_infra');
        $status_milik = $this->request->getPost('status_milik');
        $nama_milik = $this->request->getPost('nama_milik');
        $unit_pengelola = $this->request->getPost('unit_pengelola');
        $lokasi = $this->request->getPost('lokasi');
        $kap_storage = $this->request->getPost('kap_storage');
        $biaya_cloud = $this->request->getPost('biaya_cloud');
        $unit_pengembangan_cloud = $this->request->getPost('unit_pengembangan_cloud');
        $metode_akses_storage = $this->request->getPost('metode_akses_storage');
        $memori_server = $this->request->getPost('memori_server');
        $processor_server = $this->request->getPost('processor_server');
        $penyimpanan_server = $this->request->getPost('penyimpanan_server');
        $valid_server = $this->request->getPost('valid_server');
        $bw_internet = $this->request->getPost('bw_internet');
        $bw_intranet = $this->request->getPost('bw_intranet');
        $tier = $this->request->getPost('tier');
        $pengamanan_dc = $this->request->getPost('pengamanan_dc');
        $status_infra = $this->request->getPost('status_infra');
        $arsitektur_infra = $this->request->getPost('level1') . "." . $this->request->getPost('level2') . "." . $this->request->getPost('level3');

        $updateData = [
            'nama_satker' => $nama_satker,
            'jenis_infra' => $jenis_infra,
            'nama_infra' => $nama_infra,
            'desc_infra' => $desc_infra,
            'tipe_infra' => $tipe_infra,
            'status_milik' => $status_milik,
            'nama_milik' => $nama_milik,
            'unit_pengelola' => $unit_pengelola,
            'lokasi' => $lokasi,
            'kap_storage' => $kap_storage,
            'biaya_cloud' => $biaya_cloud,
            'unit_pengembangan_cloud' => $unit_pengembangan_cloud,
            'metode_akses_storage' => $metode_akses_storage,
            'memori_server' => $memori_server,
            'processor_server' => $processor_server,
            'penyimpanan_server' => $penyimpanan_server,
            'valid_server' => $valid_server,
            'bw_internet' => $bw_internet,
            'bw_intranet' => $bw_intranet,
            'tier' => $tier,
            'pengamanan_dc' => $pengamanan_dc,
            'status_infra' => $status_infra,
            'arsitektur_infra' => $arsitektur_infra,
        ];

        $infrastrukturModel->set($updateData)->where('kode_aset', $kode_aset)->update();
        session()->setFlashdata('message', 'Data Infrastruktur Berhasil Diupdate');

        return redirect()->to(base_url('satker/infrastruktur'));
    }
}
