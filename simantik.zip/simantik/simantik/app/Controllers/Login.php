<?php

namespace App\Controllers;

use App\Models\LoginModel;

use CodeIgniter\Controller;


class Login extends Controller
{
    public function index()
    {
        //
        $session = session();

        if($session->get('logged_in') && $session->get('role')==1){

            return redirect()->to(base_url('satker'));}
        elseif($session->get('logged_in') && $session->get('role')==0){

            return redirect()->to(base_url('admin'));
        

        }else{

            return view('login');

        }


         

    }

    public function verifikasi(){

        $session = session();
        $loginModel = new LoginModel();

        $email =  $this->request->getPost('email');
        $password = $this->request->getPost('password');

       

        $data = $loginModel->where('email', $email)->first();
        if($data){

            $passlama = $data['password'];

            if(password_verify($password, $passlama)){



                $ses_data = [
                    'nama'          => $data['nama'],
                    'email'         => $data['email'],
                    'no_wa'         => $data['no_wa'],
                    'nama_satker'   => $data['nama_satker'],
                    'role'          => $data['role'],
                    'logged_in'     => TRUE
                ];
                $session->set($ses_data);
                if($data['role']==0){
                    return redirect()->to(base_url('admin'));
                }else{
                    return redirect()->to(base_url('satker'));
                }
    
                
    
    
    
            } else{
    
                session()->setFlashdata('message', '<font style="color: red">Email atau Password Tidak Sesuai</font>');
                return redirect()->to(base_url('login'));
    
    
    
            }
        } 
        else {

            $session->setFlashdata('message', 'Email not Found');
            return redirect()->to(base_url('login'));



        }
      
        
        

        



    }

    public function logout()
    {
        $session = session();
        $session->destroy();
        return redirect()->to(base_url('login'));
    }







}
