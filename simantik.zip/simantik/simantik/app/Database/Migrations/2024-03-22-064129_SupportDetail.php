<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class SupportDetail extends Migration
{
    public function up()
    {
        //
        $this->forge->addField([
            'id'           => [
            'type'           => 'INT',
            'constraint'     => 11,
            'unsigned'       => TRUE,
            'auto_increment' => TRUE
         ],
         'kode_request'       => [
             'type'           => 'VARCHAR',
             'constraint'     => '10',
         ],
         'detail'       => [
            'type'           => 'TEXT',
        ],
        'file_pendukung'       => [
            'type'           => 'VARCHAR',
            'constraint'     => '255',
        ],
        'created_by'       => [
            'type'           => 'INT',
            'constraint'     => '11',
        ],
        'created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP',
         
        
        ]);
        $this->forge->addKey('id', TRUE);
        $this->forge->createTable('tb_support_detail');
    }

    public function down()
    {
        //
        $this->forge->dropTable('tb_support_detail');
    }
}
