<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class SupportRequest extends Migration
{
    public function up()
    {
        //
        $this->forge->addField([
            'id'           => [
            'type'           => 'INT',
            'constraint'     => 11,
            'unsigned'       => TRUE,
            'auto_increment' => TRUE
         ],
         'kode_request'       => [
             'type'           => 'VARCHAR',
             'constraint'     => '10',
         ],
         'id_jenis_support'       => [
            'type'           => 'INT',
            'constraint'     => '11',
        ],
        'kode_aset'       => [
            'type'           => 'VARCHAR',
            'constraint'     => '20',
        ],
        'status'       => [
            'type'           => 'INT',
            'constraint'     => '1',
        ],
        'kode_satker'       => [
            'type'           => 'VARCHAR',
            'constraint'     => '255',
        ],
        'created_by'       => [
            'type'           => 'INT',
            'constraint'     => '11',
        ],
        'created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP',
        
         
        
        ]);
        $this->forge->addKey('id', TRUE);
        $this->forge->createTable('tb_permohonan_support');
    }

    public function down()
    {
        //
        $this->forge->dropTable('tb_permohonan_support');
    }
}
