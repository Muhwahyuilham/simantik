<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class User extends Migration
{
    public function up()
    {
        //
            $this->forge->addField([
                 'id'           => [
                 'type'           => 'INT',
                 'constraint'     => 11,
                 'unsigned'       => TRUE,
                 'auto_increment' => TRUE
              ],
              'nama'       => [
                  'type'           => 'VARCHAR',
                  'constraint'     => '50',
              ],
              'email'       => [
                'type'           => 'VARCHAR',
                'constraint'     => '50',
              ],
              'no_wa'       => [
                'type'           => 'varchar',
                'constraint'     => '15',
                
              ],
              'password'       => [
                'type'           => 'VARCHAR',
                'constraint'     => '255',
              ],
              'nama_satker'       => [
                'type'           => 'VARCHAR',
                'constraint'     => '255',
              ],
            
              'role'       => [
                'type'           => 'int',
                'constraint'     => 10,
                'unsigned'       => TRUE,
              ],
              'created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP',
              'updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP',

             
        ]);
        $this->forge->addKey('id', TRUE);
        $this->forge->createTable('tb_user');
    }

    public function down()
    {
        //

        $this->forge->dropTable('tb_user');
    }
}
