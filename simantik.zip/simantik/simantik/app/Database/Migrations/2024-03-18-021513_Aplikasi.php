<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class Aplikasi extends Migration
{
    public function up()
    {
        //
        $this->forge->addField([
            'id'           => [
            'type'           => 'INT',
            'constraint'     => 11,
            'unsigned'       => TRUE,
            'auto_increment' => TRUE
         ],
         'kode_aset'       => [
             'type'           => 'VARCHAR',
             'constraint'     => '20',
         ],
         'nama_satker'       => [
           'type'           => 'varchar',
           'constraint'     => '255',
         ],
         'nama_app'       => [
            'type'           => 'VARCHAR',
            'constraint'     => '255',
          ],
          'desc_app'       => [
            'type'           => 'TEXT',
           
          ],
          'fungsi_app'       => [
            'type'           => 'TEXT',
           
          ],
          'output_app'       => [
            'type'           => 'VARCHAR',
           'constraint'     => '255',
          ],
          'basis_app'       => [
            'type'           => 'VARCHAR',
            'constraint'     => '100',
          ],

          'url_app'       => [
            'type'           => 'VARCHAR',
            'constraint'     => '255',
           
          ],
          'prog_lang'       => [
            'type'           => 'VARCHAR',
            'constraint'     => '50',
           
          ],
          
          'prog_lang_ver'       => [
            'type'           => 'VARCHAR',
            'constraint'     => '20',
           
          ],
          'db_app'       => [
            'type'           => 'VARCHAR',
            'constraint'     => '50',
           
          ],
          'db_ver'       => [
            'type'           => 'VARCHAR',
            'constraint'     => '20',
           
          ],
          'db_name'       => [
            'type'           => 'VARCHAR',
            'constraint'     => '50',
           
          ],
          'framework'       => [
            'type'           => 'VARCHAR',
            'constraint'     => '20',
           
          ],
          'framework_ver'       => [
            'type'           => 'VARCHAR',
            'constraint'     => '20',
          ],
          'dev_model'       => [
            'type'           => 'int',
            'constraint'     => 10,
            'unsigned'       => TRUE,
          ],
          'dev_unit'       => [
            'type'           => 'VARCHAR',
            'constraint'     => '255',
          ],
          'dev_year' => [
            'type'           => 'int',
            'constraint'     => 10,
            'unsigned'       => TRUE,
          ],
          'arch_model'       => [
            'type'           => 'int',
            'constraint'     => 10,
            'unsigned'       => TRUE,
          ],  
         'source_code'       => [
           'type'           => 'int',
           'constraint'     => 10,
           'unsigned'       => TRUE,
         ],
         'license_type'    => [
          'type'          => 'int',
          'constraint'     => '10',
          'unsigned'      => true
        ],
        'sec_test'       => [
          'type'           => 'int',
          'constraint'     => 10,
          'unsigned'       => TRUE,
        ],
         'hosting_app'       => [
           'type'           => 'VARCHAR',
           'constraint'     => '50',
         ],
         'pointing_ip'       => [
           'type'           => 'VARCHAR',
           'constraint'     => '20',
         ],
         'status_app'       => [
           'type'           => 'int',
           'constraint'     => 10,
           'unsigned'       => TRUE,
         ],
         'arsitektur_app'       => [
          'type'           => 'VARCHAR',
          'constraint'     => '20',
        ],
        'arsitektur_probis'       => [
          'type'           => 'VARCHAR',
          'constraint'     => '20',
        ],
         'created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP',
         'updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP',
        
        ]);
        $this->forge->addKey('id', TRUE);
        $this->forge->createTable('tb_aplikasi');
    }

    public function down()
    {
        //
        $this->forge->dropTable('tb_aplikasi');
    }
}
