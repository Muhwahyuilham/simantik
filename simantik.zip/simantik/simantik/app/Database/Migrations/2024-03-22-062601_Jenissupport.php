<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class Jenissupport extends Migration
{
    public function up()
    {
        //
        $this->forge->addField([
            'id'           => [
            'type'           => 'INT',
            'constraint'     => 11,
            'unsigned'       => TRUE,
            'auto_increment' => TRUE
         ],
         'jenis_support'       => [
             'type'           => 'VARCHAR',
             'constraint'     => '64',
         ],
        //  'created_by'       => [
        //     'type'           => 'int',
        //     'constraint'     => 10,
        //     'unsigned'       => TRUE,
        //   ],
         'created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP',
        //  'updated_by'       => [
        //     'type'           => 'int',
        //     'constraint'     => 10,
        //     'unsigned'       => TRUE,
        //   ],
         'updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP',
         
        
        ]);
        $this->forge->addKey('id', TRUE);
        $this->forge->createTable('tb_jenis_support');
    }

    public function down()
    {
        //
        $this->forge->dropTable('tb_jenis_support');

    }
}
