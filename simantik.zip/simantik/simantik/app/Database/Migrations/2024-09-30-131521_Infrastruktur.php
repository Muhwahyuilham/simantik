<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class Infrastruktur extends Migration
{
    public function up()
    {
         //
         $this->forge->addField([
            'id'           => [
            'type'           => 'INT',
            'constraint'     => 11,
            'unsigned'       => TRUE,
            'auto_increment' => TRUE
         ],
         'kode_aset'       => [
             'type'           => 'VARCHAR',
             'constraint'     => '20',
         ],
         'nama_satker'       => [
           'type'           => 'varchar',
           'constraint'     => '255',
         ],
         'jenis_infra'       => [
            'type'           => 'VARCHAR',
            'constraint'     => '20',
          ],
          'nama_infra'       => [
            'type'           => 'VARCHAR',
            'constraint'     => '255',
           
          ],
          'desc_infra'       => [
            'type'           => 'TEXT',
           
          ],
          'tipe_infra'       => [
            'type'           => 'VARCHAR',
           'constraint'     => '255',

          ],
          'status_milik'       => [
            'type'           => 'boolean',

          ],

          'nama_milik'       => [
            'type'           => 'VARCHAR',
            'constraint'     => '255',
           
          ],
          'unit_pengelola'       => [
            'type'           => 'VARCHAR',
            'constraint'     => '255',
           
          ],
          
          'lokasi'       => [
            'type'           => 'VARCHAR',
            'constraint'     => '255',
           
          ],
          'kap_storage'       => [
            'type'           => 'INT',
            'constraint'     => 20,
            'unsigned'       => TRUE
           
          ],
          'biaya_cloud'       => [
            'type'           => 'INT',
            'constraint'     => 20,
            'unsigned'       => TRUE,
           
          ],
          'unit_pengembangan_cloud'       => [
            'type'           => 'VARCHAR',
            'constraint'     => '100',
           
          ],
          'metode_akses_storage'       => [
            'type'           => 'VARCHAR',
            'constraint'     => '50',
           
          ],
         'memori_server'       => [
            'type'           => 'int',
            'constraint'     => 20,
            'unsigned'       => TRUE,
          ],
          'processor_server'       => [
            'type'           => 'VARCHAR',
            'constraint'     => '255',
          ],
          'penyimpanan_serve'       => [
            'type'           => 'VARCHAR',
            'constraint'     => '255',
          ],
          'valid_server' => [
            'type'           => 'DATE',
            
          ],
          'bw_internet'       => [
            'type'           => 'int',
            'constraint'     => 10,
            'unsigned'       => TRUE,
          ],  
         'bw_intranet'       => [
           'type'           => 'int',
           'constraint'     => 10,
           'unsigned'       => TRUE,
         ],
         'tier'    => [
          'type'          => 'int',
          'constraint'     => 5,
          'unsigned'      => true
        ],
       'pengamanan_dc'       => [
            'type'           => 'VARCHAR',
            'constraint'     => '255',
        ],
         'status_infra'       => [
           'type'           => 'INT',
           'constraint'     => 10 ,
           'unsigned'       => TRUE,
         ],
         'arsitektur_infra'       => [
           'type'           => 'VARCHAR',
           'constraint'     => '20',
         ],
         'created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP',
         'updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP',
        
        ]);
        $this->forge->addKey('id', TRUE);
        $this->forge->createTable('tb_infrastruktur');
    }

    public function down()
    {
        //
        $this->forge->dropTable('tb_infrastruktur');
    }
}
