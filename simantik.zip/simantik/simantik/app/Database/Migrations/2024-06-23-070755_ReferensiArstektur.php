<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class ReferensiArstektur extends Migration
{
    public function up()
    {
        //
        $this->forge->addField([
            'id'           => [
              'type'           => 'INT',
              'constraint'     => 11,
              'unsigned'       => TRUE,
              'auto_increment' => TRUE
            ],
           'kode_referensi'       => [
               'type'           => 'VARCHAR',
               'constraint'     => '2',   
           ],
           'nama_referensi'       => [
             'type'           => 'VARCHAR',
             'constraint'     => '255',
           ],
           'level'       => [
              'type'           => 'int',
              'constraint'     => '5',
              'unsigned'        => true
            ],
          
     ]);
     $this->forge->addKey('id', TRUE);
     $this->forge->createTable('m_referensi_arsitektur');
    }

    public function down()
    {
        //
        $this->forge->dropTable('m_referensi_arsitektur');
    }
}
