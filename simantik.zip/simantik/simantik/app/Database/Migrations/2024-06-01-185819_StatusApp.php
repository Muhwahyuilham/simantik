<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class StatusApp extends Migration
{
    public function up()
    {
        //
        $this->forge->addField([
            'id'           => [
            'type'           => 'INT',
            'constraint'     => 11,
            'unsigned'       => TRUE,
            'auto_increment' => TRUE
         ],
         'status_app'       => [
             'type'           => 'VARCHAR',
             'constraint'     => '20',
         ],
         'status_color'       => [
            'type'           => 'varchar',
            'constraint'     => 10
        ],
        'created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP',
        'updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP',
         
        
        ]);
        $this->forge->addKey('id', TRUE);
        $this->forge->createTable('tb_status_app');
    }

    public function down()
    {
        //
        $this->forge->dropTable('tb_status_app');
    }
}
